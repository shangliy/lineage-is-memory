Held-out best per run, and per label the share of proposals that get all search examples of the label right (first number) and the held-out best candidates that get all held-out examples right (second). Tokens exclude held-out scoring; to solve: median over runs that solved the search set.

| cell | runs | tokens / run | solved | tokens to solve | best chars | held-out best | iso_date | us_date | eu_date | time | ipv4 | ipv6 | mac_address | uuid | email | url | hex_color | semver |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| parent-full-clustergold | 10 | 36089 | 10/10 | 32877 | 1286 | 0.992 [0.979, 1.000] | 20/21, 10/10 | 20/21, 8/10 | 17/21, 10/10 | 12/21, 10/10 | 18/21, 10/10 | 19/21, 10/10 | 18/21, 10/10 | 21/21, 10/10 | 19/21, 10/10 | 21/21, 10/10 | 20/21, 10/10 | 18/21, 10/10 |
| parent-full-first | 10 | 43803 | 10/10 | 40370 | 1337 | 0.958 [0.942, 0.975] | 31/33, 10/10 | 31/33, 10/10 | 28/33, 8/10 | 22/33, 10/10 | 22/33, 10/10 | 22/33, 10/10 | 31/33, 7/10 | 33/33, 10/10 | 33/33, 10/10 | 33/33, 10/10 | 24/33, 7/10 | 13/33, 9/10 |
| parent-full-minibatch | 10 | 80645 | 7/10 | 43935 | 1436 | 0.950 [0.921, 0.979] | 33/48, 9/10 | 45/48, 9/10 | 37/48, 9/10 | 33/48, 10/10 | 42/48, 10/10 | 42/48, 10/10 | 48/48, 8/10 | 48/48, 10/10 | 48/48, 10/10 | 48/48, 10/10 | 45/48, 8/10 | 27/48, 8/10 |
| seed-full-clustergold | 10 | 84759 | 2/10 | 66922 | 879 | 0.904 [0.862, 0.933] | 60/65, 10/10 | 62/65, 10/10 | 58/65, 9/10 | 2/65, 2/10 | 51/65, 9/10 | 51/65, 9/10 | 60/65, 9/10 | 65/65, 10/10 | 63/65, 10/10 | 63/65, 10/10 | 63/65, 8/10 | 61/65, 10/10 |
| seed-full-first | 10 | 73750 | 0/10 | - | 832 | 0.725 [0.688, 0.767] | 64/70, 10/10 | 60/70, 10/10 | 54/70, 10/10 | 0/70, 3/10 | 1/70, 1/10 | 1/70, 1/10 | 69/70, 10/10 | 69/70, 10/10 | 67/70, 10/10 | 70/70, 10/10 | 59/70, 6/10 | 1/70, 1/10 |
| seed-full-minibatch | 10 | 74058 | 0/10 | - | 753 | 0.775 [0.721, 0.846] | 51/70, 9/10 | 53/70, 9/10 | 38/70, 8/10 | 23/70, 4/10 | 29/70, 5/10 | 27/70, 4/10 | 67/70, 10/10 | 69/70, 10/10 | 68/70, 10/10 | 69/70, 10/10 | 59/70, 6/10 | 18/70, 2/10 |
| seed-none | 10 | 82331 | 0/10 | - | 934 | 0.671 [0.642, 0.696] | 28/70, 9/10 | 51/70, 10/10 | 39/70, 9/10 | 4/70, 2/10 | 0/70, 0/10 | 0/70, 0/10 | 65/70, 10/10 | 63/70, 10/10 | 70/70, 10/10 | 70/70, 10/10 | 56/70, 7/10 | 2/70, 0/10 |

Wrong answers shown to the seed's first rewrite:

- parent-full-clustergold run 0: 
- parent-full-clustergold run 1: 
- parent-full-clustergold run 2: 
- parent-full-clustergold run 3: 
- parent-full-clustergold run 4: 
- parent-full-clustergold run 5: 
- parent-full-clustergold run 6: 
- parent-full-clustergold run 7: 
- parent-full-clustergold run 8: 
- parent-full-clustergold run 9: 
- parent-full-first run 0: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- parent-full-first run 1: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- parent-full-first run 2: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- parent-full-first run 3: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- parent-full-first run 4: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- parent-full-first run 5: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- parent-full-first run 6: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- parent-full-first run 7: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- parent-full-first run 8: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- parent-full-first run 9: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- parent-full-minibatch run 0: '12/31/1999', '00:1A:2B:3C:4D:5E', 'a4:83:e7:0b:9c:12', '#FFF'
- parent-full-minibatch run 1: '1999-12-31', '03/15/2024', '14:05', 'j.smith+news@mail.co.uk'
- parent-full-minibatch run 2: '23:59:59', 'a4:83:e7:0b:9c:12', 'ana@example.com', 'http://localhost:8080'
- parent-full-minibatch run 3: '23:59:59', 'fe80::1ff:fe23:4567:890a', 'f47ac10b-58cc-4372-a567-0e02b2c3d479', 'j.smith+news@mail.co.uk'
- parent-full-minibatch run 4: '12/31/1999', 'a4:83:e7:0b:9c:12', 'http://localhost:8080', '2.0.0-rc.1'
- parent-full-minibatch run 5: '00:1A:2B:3C:4D:5E', 'a4:83:e7:0b:9c:12', 'f47ac10b-58cc-4372-a567-0e02b2c3d479', 'j.smith+news@mail.co.uk'
- parent-full-minibatch run 6: '1999-12-31', '23:59:59', 'fe80::1ff:fe23:4567:890a', '123e4567-e89b-12d3-a456-426614174000'
- parent-full-minibatch run 7: '1999-12-31', '31.12.1999', '8.8.8.8', 'http://localhost:8080'
- parent-full-minibatch run 8: '03/15/2024', '2001:db8::1', '123e4567-e89b-12d3-a456-426614174000', 'ana@example.com'
- parent-full-minibatch run 9: '2024-03-15', '03/15/2024', '31.12.1999', 'f47ac10b-58cc-4372-a567-0e02b2c3d479'
- seed-full-clustergold run 0: 
- seed-full-clustergold run 1: 
- seed-full-clustergold run 2: 
- seed-full-clustergold run 3: 
- seed-full-clustergold run 4: 
- seed-full-clustergold run 5: 
- seed-full-clustergold run 6: 
- seed-full-clustergold run 7: 
- seed-full-clustergold run 8: 
- seed-full-clustergold run 9: 
- seed-full-first run 0: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- seed-full-first run 1: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- seed-full-first run 2: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- seed-full-first run 3: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- seed-full-first run 4: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- seed-full-first run 5: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- seed-full-first run 6: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- seed-full-first run 7: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- seed-full-first run 8: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- seed-full-first run 9: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- seed-full-minibatch run 0: '12/31/1999', '00:1A:2B:3C:4D:5E', 'a4:83:e7:0b:9c:12', '#FFF'
- seed-full-minibatch run 1: '1999-12-31', '03/15/2024', '14:05', 'j.smith+news@mail.co.uk'
- seed-full-minibatch run 2: '23:59:59', 'a4:83:e7:0b:9c:12', 'ana@example.com', 'http://localhost:8080'
- seed-full-minibatch run 3: '23:59:59', 'fe80::1ff:fe23:4567:890a', 'f47ac10b-58cc-4372-a567-0e02b2c3d479', 'j.smith+news@mail.co.uk'
- seed-full-minibatch run 4: '12/31/1999', 'a4:83:e7:0b:9c:12', 'http://localhost:8080', '2.0.0-rc.1'
- seed-full-minibatch run 5: '00:1A:2B:3C:4D:5E', 'a4:83:e7:0b:9c:12', 'f47ac10b-58cc-4372-a567-0e02b2c3d479', 'j.smith+news@mail.co.uk'
- seed-full-minibatch run 6: '1999-12-31', '23:59:59', 'fe80::1ff:fe23:4567:890a', '123e4567-e89b-12d3-a456-426614174000'
- seed-full-minibatch run 7: '1999-12-31', '31.12.1999', '8.8.8.8', 'http://localhost:8080'
- seed-full-minibatch run 8: '03/15/2024', '2001:db8::1', '123e4567-e89b-12d3-a456-426614174000', 'ana@example.com'
- seed-full-minibatch run 9: '2024-03-15', '03/15/2024', '31.12.1999', 'f47ac10b-58cc-4372-a567-0e02b2c3d479'

Mean [bootstrap 95% interval over runs].
