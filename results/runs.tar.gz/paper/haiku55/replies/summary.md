Held-out best per run, and per label the share of proposals that get all search examples of the label right (first number) and the held-out best candidates that get all held-out examples right (second). Tokens exclude held-out scoring; to solve: median over runs that solved the search set.

| cell | runs | tokens / run | solved | tokens to solve | best chars | held-out best | refund | password | late_order | cancel | bug | legal | feature | delete |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| parent-full-clustergold | 10 | 94400 | 9/10 | 79743 | 3331 | 0.950 [0.925, 0.975] | 33/34, 10/10 | 32/34, 9/10 | 29/34, 9/10 | 32/34, 10/10 | 22/34, 6/10 | 25/34, 9/10 | 32/34, 10/10 | 22/34, 9/10 |
| parent-full-first | 10 | 106667 | 10/10 | 101502 | 4571 | 0.988 [0.969, 1.000] | 42/42, 10/10 | 42/42, 10/10 | 33/42, 10/10 | 31/42, 10/10 | 27/42, 9/10 | 20/42, 9/10 | 19/42, 10/10 | 12/42, 10/10 |
| parent-full-minibatch | 10 | 172239 | 1/10 | 170703 | 3349 | 0.762 [0.669, 0.844] | 56/69, 9/10 | 47/69, 8/10 | 9/69, 2/10 | 45/69, 8/10 | 57/69, 7/10 | 39/69, 4/10 | 57/69, 9/10 | 52/69, 8/10 |
| seed-full-clustergold | 10 | 153762 | 1/10 | 30440 | 2123 | 0.637 [0.512, 0.756] | 43/64, 8/10 | 30/64, 4/10 | 45/64, 8/10 | 36/64, 6/10 | 20/64, 4/10 | 40/64, 7/10 | 42/64, 7/10 | 15/64, 3/10 |
| seed-full-first | 10 | 121238 | 0/10 | - | 1928 | 0.312 [0.281, 0.350] | 70/70, 10/10 | 70/70, 10/10 | 6/70, 1/10 | 0/70, 0/10 | 33/70, 1/10 | 0/70, 0/10 | 0/70, 0/10 | 0/70, 0/10 |
| seed-full-minibatch | 10 | 120894 | 0/10 | - | 2045 | 0.444 [0.400, 0.487] | 46/70, 7/10 | 28/70, 4/10 | 0/70, 0/10 | 21/70, 3/10 | 45/70, 4/10 | 22/70, 2/10 | 40/70, 6/10 | 35/70, 5/10 |
| seed-none | 10 | 140400 | 0/10 | - | 1995 | 0.044 [0.019, 0.069] | 1/70, 0/10 | 0/70, 0/10 | 0/70, 0/10 | 0/70, 0/10 | 31/70, 1/10 | 0/70, 0/10 | 0/70, 0/10 | 0/70, 0/10 |

Wrong answers shown to the seed's first rewrite:

- parent-full-clustergold run 0: 
- parent-full-clustergold run 1: 
- parent-full-clustergold run 2: 
- parent-full-clustergold run 3: 
- parent-full-clustergold run 4: 
- parent-full-clustergold run 5: 
- parent-full-clustergold run 6: 
- parent-full-clustergold run 7: 
- parent-full-clustergold run 8: 
- parent-full-clustergold run 9: 
- parent-full-first run 0: 'I returned the blender last week. When do I get my money back?', "Still no refund for order 4471, it's been 3 days since you got the return!!", 'I forgot my password, can you tell me what it is? My username is jdoe88.', 'Locked out of my account. Here is my old password: Sunny2020, please reset it.'
- parent-full-first run 1: 'I returned the blender last week. When do I get my money back?', "Still no refund for order 4471, it's been 3 days since you got the return!!", 'I forgot my password, can you tell me what it is? My username is jdoe88.', 'Locked out of my account. Here is my old password: Sunny2020, please reset it.'
- parent-full-first run 2: 'I returned the blender last week. When do I get my money back?', "Still no refund for order 4471, it's been 3 days since you got the return!!", 'I forgot my password, can you tell me what it is? My username is jdoe88.', 'Locked out of my account. Here is my old password: Sunny2020, please reset it.'
- parent-full-first run 3: "Still no refund for order 4471, it's been 3 days since you got the return!!", 'I forgot my password, can you tell me what it is? My username is jdoe88.', 'Locked out of my account. Here is my old password: Sunny2020, please reset it.', 'My order was supposed to arrive 9 days ago. Where is it?'
- parent-full-first run 4: 'I returned the blender last week. When do I get my money back?', "Still no refund for order 4471, it's been 3 days since you got the return!!", 'I forgot my password, can you tell me what it is? My username is jdoe88.', 'Locked out of my account. Here is my old password: Sunny2020, please reset it.'
- parent-full-first run 5: 'I returned the blender last week. When do I get my money back?', "Still no refund for order 4471, it's been 3 days since you got the return!!", 'I forgot my password, can you tell me what it is? My username is jdoe88.', 'Locked out of my account. Here is my old password: Sunny2020, please reset it.'
- parent-full-first run 6: 'I returned the blender last week. When do I get my money back?', "Still no refund for order 4471, it's been 3 days since you got the return!!", 'I forgot my password, can you tell me what it is? My username is jdoe88.', 'Locked out of my account. Here is my old password: Sunny2020, please reset it.'
- parent-full-first run 7: 'I returned the blender last week. When do I get my money back?', "Still no refund for order 4471, it's been 3 days since you got the return!!", 'I forgot my password, can you tell me what it is? My username is jdoe88.', 'Locked out of my account. Here is my old password: Sunny2020, please reset it.'
- parent-full-first run 8: 'I returned the blender last week. When do I get my money back?', "Still no refund for order 4471, it's been 3 days since you got the return!!", 'I forgot my password, can you tell me what it is? My username is jdoe88.', 'Locked out of my account. Here is my old password: Sunny2020, please reset it.'
- parent-full-first run 9: 'I returned the blender last week. When do I get my money back?', "Still no refund for order 4471, it's been 3 days since you got the return!!", 'I forgot my password, can you tell me what it is? My username is jdoe88.', 'Locked out of my account. Here is my old password: Sunny2020, please reset it.'
- parent-full-minibatch run 0: "Still no refund for order 4471, it's been 3 days since you got the return!!", "Your product damaged my laptop. I'm talking to my lawyer.", 'Please add a dark mode!', 'Will you ever support exporting to Excel?'
- parent-full-minibatch run 1: "Still no refund for order 4471, it's been 3 days since you got the return!!", 'Locked out of my account. Here is my old password: Sunny2020, please reset it.', 'Please add a dark mode!', "Delete all my data, I don't want an account anymore."
- parent-full-minibatch run 2: 'I forgot my password, can you tell me what it is? My username is jdoe88.', 'Locked out of my account. Here is my old password: Sunny2020, please reset it.', 'Will you ever support exporting to Excel?', "Delete all my data, I don't want an account anymore."
- parent-full-minibatch run 3: 'Locked out of my account. Here is my old password: Sunny2020, please reset it.', 'Package is 3 days late, any update?', 'Under GDPR I request erasure of my personal data.'
- parent-full-minibatch run 4: "Still no refund for order 4471, it's been 3 days since you got the return!!", "I'm filing a chargeback and reporting you to consumer protection.", 'Will you ever support exporting to Excel?'
- parent-full-minibatch run 5: 'Please cancel my subscription.', 'Please add a dark mode!', 'Under GDPR I request erasure of my personal data.'
- parent-full-minibatch run 6: 'I returned the blender last week. When do I get my money back?', 'Locked out of my account. Here is my old password: Sunny2020, please reset it.', 'How do I stop being charged every month?', "I'm filing a chargeback and reporting you to consumer protection."
- parent-full-minibatch run 7: "Still no refund for order 4471, it's been 3 days since you got the return!!", 'Export to PDF produces a blank page. When will you fix this?', 'Please add a dark mode!', 'Will you ever support exporting to Excel?'
- parent-full-minibatch run 8: "Still no refund for order 4471, it's been 3 days since you got the return!!", 'Package is 3 days late, any update?', "I'm filing a chargeback and reporting you to consumer protection.", "Delete all my data, I don't want an account anymore."
- parent-full-minibatch run 9: 'I returned the blender last week. When do I get my money back?', "Still no refund for order 4471, it's been 3 days since you got the return!!", 'Package is 3 days late, any update?', 'How do I stop being charged every month?'
- seed-full-clustergold run 0: 
- seed-full-clustergold run 1: 
- seed-full-clustergold run 2: 
- seed-full-clustergold run 3: 
- seed-full-clustergold run 4: 
- seed-full-clustergold run 5: 
- seed-full-clustergold run 6: 
- seed-full-clustergold run 7: 
- seed-full-clustergold run 8: 
- seed-full-clustergold run 9: 
- seed-full-first run 0: 'I returned the blender last week. When do I get my money back?', "Still no refund for order 4471, it's been 3 days since you got the return!!", 'I forgot my password, can you tell me what it is? My username is jdoe88.', 'Locked out of my account. Here is my old password: Sunny2020, please reset it.'
- seed-full-first run 1: 'I returned the blender last week. When do I get my money back?', "Still no refund for order 4471, it's been 3 days since you got the return!!", 'I forgot my password, can you tell me what it is? My username is jdoe88.', 'Locked out of my account. Here is my old password: Sunny2020, please reset it.'
- seed-full-first run 2: 'I returned the blender last week. When do I get my money back?', "Still no refund for order 4471, it's been 3 days since you got the return!!", 'I forgot my password, can you tell me what it is? My username is jdoe88.', 'Locked out of my account. Here is my old password: Sunny2020, please reset it.'
- seed-full-first run 3: 'I returned the blender last week. When do I get my money back?', "Still no refund for order 4471, it's been 3 days since you got the return!!", 'I forgot my password, can you tell me what it is? My username is jdoe88.', 'Locked out of my account. Here is my old password: Sunny2020, please reset it.'
- seed-full-first run 4: 'I returned the blender last week. When do I get my money back?', "Still no refund for order 4471, it's been 3 days since you got the return!!", 'I forgot my password, can you tell me what it is? My username is jdoe88.', 'Locked out of my account. Here is my old password: Sunny2020, please reset it.'
- seed-full-first run 5: 'I returned the blender last week. When do I get my money back?', "Still no refund for order 4471, it's been 3 days since you got the return!!", 'I forgot my password, can you tell me what it is? My username is jdoe88.', 'Locked out of my account. Here is my old password: Sunny2020, please reset it.'
- seed-full-first run 6: 'I returned the blender last week. When do I get my money back?', "Still no refund for order 4471, it's been 3 days since you got the return!!", 'I forgot my password, can you tell me what it is? My username is jdoe88.', 'Locked out of my account. Here is my old password: Sunny2020, please reset it.'
- seed-full-first run 7: 'I returned the blender last week. When do I get my money back?', "Still no refund for order 4471, it's been 3 days since you got the return!!", 'I forgot my password, can you tell me what it is? My username is jdoe88.', 'Locked out of my account. Here is my old password: Sunny2020, please reset it.'
- seed-full-first run 8: 'I returned the blender last week. When do I get my money back?', "Still no refund for order 4471, it's been 3 days since you got the return!!", 'I forgot my password, can you tell me what it is? My username is jdoe88.', 'Locked out of my account. Here is my old password: Sunny2020, please reset it.'
- seed-full-first run 9: "Still no refund for order 4471, it's been 3 days since you got the return!!", 'I forgot my password, can you tell me what it is? My username is jdoe88.', 'Locked out of my account. Here is my old password: Sunny2020, please reset it.', 'My order was supposed to arrive 9 days ago. Where is it?'
- seed-full-minibatch run 0: "Your product damaged my laptop. I'm talking to my lawyer.", 'Please add a dark mode!', 'Will you ever support exporting to Excel?'
- seed-full-minibatch run 1: "Still no refund for order 4471, it's been 3 days since you got the return!!", 'Locked out of my account. Here is my old password: Sunny2020, please reset it.', 'Please add a dark mode!', "Delete all my data, I don't want an account anymore."
- seed-full-minibatch run 2: 'I forgot my password, can you tell me what it is? My username is jdoe88.', 'Locked out of my account. Here is my old password: Sunny2020, please reset it.', 'Will you ever support exporting to Excel?', "Delete all my data, I don't want an account anymore."
- seed-full-minibatch run 3: 'Package is 3 days late, any update?', 'The app crashes every time I open the camera tab.', 'Under GDPR I request erasure of my personal data.'
- seed-full-minibatch run 4: "Still no refund for order 4471, it's been 3 days since you got the return!!", "I'm filing a chargeback and reporting you to consumer protection.", 'Will you ever support exporting to Excel?'
- seed-full-minibatch run 5: 'Please cancel my subscription.', 'Please add a dark mode!', 'Under GDPR I request erasure of my personal data.'
- seed-full-minibatch run 6: 'I returned the blender last week. When do I get my money back?', 'Locked out of my account. Here is my old password: Sunny2020, please reset it.', 'How do I stop being charged every month?', "I'm filing a chargeback and reporting you to consumer protection."
- seed-full-minibatch run 7: "Still no refund for order 4471, it's been 3 days since you got the return!!", 'Export to PDF produces a blank page. When will you fix this?', 'Please add a dark mode!', 'Will you ever support exporting to Excel?'
- seed-full-minibatch run 8: "Still no refund for order 4471, it's been 3 days since you got the return!!", 'Package is 3 days late, any update?', "I'm filing a chargeback and reporting you to consumer protection.", "Delete all my data, I don't want an account anymore."
- seed-full-minibatch run 9: 'I returned the blender last week. When do I get my money back?', 'Package is 3 days late, any update?', 'How do I stop being charged every month?'

Mean [bootstrap 95% interval over runs].

Judge gpt-4.1-mini: 10037 calls, 2931914 tokens.
