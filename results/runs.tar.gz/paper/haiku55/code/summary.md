## duration

Coverage: share of proposals (first number) and of run-best candidates (second) that pass every held-out case of the category.

| cell | runs | tokens / run | solved | tokens to solve (median) | held-out best | clock | days/weeks | invalid | iso | number | units | words |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| parent-full-clustergold | 10 | 12270 | 10/10 | 11224.5 | 1.000 [1.000, 1.000] | 20/20, 10/10 | 16/20, 10/10 | 10/20, 10/10 | 18/20, 10/10 | 19/20, 10/10 | 20/20, 10/10 | 19/20, 10/10 |
| parent-full-first | 10 | 10506 | 10/10 | 11520.0 | 1.000 [1.000, 1.000] | 26/26, 10/10 | 21/26, 10/10 | 11/26, 10/10 | 16/26, 10/10 | 26/26, 10/10 | 26/26, 10/10 | 19/26, 10/10 |
| parent-full-minibatch | 10 | 41225 | 7/10 | 12023 | 0.988 [0.975, 1.000] | 54/54, 10/10 | 40/54, 10/10 | 17/54, 7/10 | 47/54, 10/10 | 54/54, 10/10 | 53/54, 10/10 | 48/54, 10/10 |
| seed-full-clustergold | 10 | 57099 | 0/10 | - | 0.942 [0.929, 0.954] | 109/109, 10/10 | 44/109, 6/10 | 1/109, 0/10 | 99/109, 10/10 | 102/109, 10/10 | 108/109, 10/10 | 84/109, 10/10 |
| seed-full-first | 10 | 33437 | 0/10 | - | 0.863 [0.833, 0.892] | 110/110, 10/10 | 21/110, 6/10 | 25/110, 3/10 | 2/110, 2/10 | 110/110, 10/10 | 109/110, 10/10 | 52/110, 10/10 |
| seed-full-minibatch | 10 | 40636 | 0/10 | - | 0.942 [0.929, 0.954] | 110/110, 10/10 | 22/110, 6/10 | 7/110, 1/10 | 46/110, 10/10 | 109/110, 10/10 | 109/110, 10/10 | 75/110, 10/10 |
| seed-none | 10 | 41344 | 1/10 | 22309 | 0.954 [0.942, 0.967] | 104/104, 10/10 | 11/104, 7/10 | 10/104, 2/10 | 41/104, 10/10 | 104/104, 10/10 | 104/104, 10/10 | 93/104, 10/10 |

Failures shown to the seed's first rewrite:

- parent-full-clustergold: '90', '1h30m', '1h 30m 15s', '3d', '1w', '2 hours', '1 minute 30 seconds', '01:30:00', '2:05', 'PT1H30M', 'P1DT2H', '1x', '-5m'
- parent-full-first: '90', '1h30m', '1h 30m 15s', '3d'
- parent-full-minibatch: '1h 30m 15s', '-5m' (run 0)
- parent-full-minibatch: 'P1DT2H' (run 1)
- parent-full-minibatch: '1h 30m 15s' (run 2)
- parent-full-minibatch: '90', '1h30m', '1x' (run 3)
- parent-full-minibatch: '1h 30m 15s', '2:05' (run 4)
- parent-full-minibatch: '01:30:00' (run 5)
- parent-full-minibatch: '90', '1 minute 30 seconds' (run 6)
- parent-full-minibatch: '1h30m', '1w', '1 minute 30 seconds', '1x' (run 7)
- parent-full-minibatch: '90' (run 8)
- parent-full-minibatch: '1h30m', '01:30:00' (run 9)
- seed-full-clustergold: '90', '1h30m', '1h 30m 15s', '3d', '1w', '2 hours', '1 minute 30 seconds', '01:30:00', '2:05', 'PT1H30M', 'P1DT2H', '1x', '-5m'
- seed-full-first: '90', '1h30m', '1h 30m 15s', '3d'
- seed-full-minibatch: '1h30m', '1h 30m 15s', '3d' (run 0)
- seed-full-minibatch: '3d', '01:30:00' (run 1)
- seed-full-minibatch: '90', 'PT1H30M' (run 2)
- seed-full-minibatch: '1 minute 30 seconds', '01:30:00' (run 3)
- seed-full-minibatch: '90' (run 4)
- seed-full-minibatch: '2 hours', '1 minute 30 seconds', '1x' (run 5)
- seed-full-minibatch: '1h 30m 15s', '1w', 'P1DT2H' (run 6)
- seed-full-minibatch: '1 minute 30 seconds' (run 7)
- seed-full-minibatch: '1h30m', '1h 30m 15s', '2 hours' (run 8)
- seed-full-minibatch: '1h 30m 15s' (run 9)

## size

Coverage: share of proposals (first number) and of run-best candidates (second) that pass every held-out case of the category.

| cell | runs | tokens / run | solved | tokens to solve (median) | held-out best | bytes | iec | invalid | letter | separator | si | words |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| parent-full-clustergold | 10 | 9432 | 10/10 | 8838.0 | 1.000 [1.000, 1.000] | 16/16, 10/10 | 15/16, 10/10 | 16/16, 10/10 | 16/16, 10/10 | 15/16, 10/10 | 14/16, 10/10 | 11/16, 10/10 |
| parent-full-first | 10 | 8544 | 10/10 | 8478.5 | 1.000 [1.000, 1.000] | 30/30, 10/10 | 21/30, 10/10 | 30/30, 10/10 | 30/30, 10/10 | 11/30, 10/10 | 30/30, 10/10 | 19/30, 10/10 |
| parent-full-minibatch | 10 | 30733 | 4/10 | 7144.0 | 0.971 [0.954, 0.988] | 75/76, 10/10 | 62/76, 9/10 | 76/76, 10/10 | 76/76, 10/10 | 15/76, 5/10 | 75/76, 10/10 | 66/76, 10/10 |
| seed-full-clustergold | 10 | 26099 | 3/10 | 6283 | 0.838 [0.758, 0.917] | 80/80, 10/10 | 21/80, 7/10 | 80/80, 10/10 | 80/80, 10/10 | 69/80, 9/10 | 25/80, 5/10 | 3/80, 3/10 |
| seed-full-first | 10 | 26439 | 0/10 | - | 0.817 [0.792, 0.833] | 110/110, 10/10 | 16/110, 8/10 | 110/110, 10/10 | 107/110, 10/10 | 0/110, 0/10 | 109/110, 10/10 | 0/110, 0/10 |
| seed-full-minibatch | 10 | 27820 | 1/10 | 5330 | 0.863 [0.800, 0.917] | 100/101, 10/10 | 55/101, 10/10 | 98/101, 10/10 | 101/101, 10/10 | 35/101, 4/10 | 72/101, 8/10 | 17/101, 3/10 |
| seed-none | 10 | 22541 | 0/10 | - | 0.650 [0.633, 0.667] | 108/110, 10/10 | 6/110, 5/10 | 110/110, 10/10 | 109/110, 10/10 | 16/110, 3/10 | 0/110, 0/10 | 0/110, 0/10 |

Failures shown to the seed's first rewrite:

- parent-full-clustergold: '512', '10KB', '1.5MB', '3 GB', '1kB', '1KiB', '4MiB', '2Gi', '256Mi', '1.5K', '512m', '10 kilobytes', '1 byte', '2 gibibytes', '1,024'
- parent-full-first: '512', '10KB', '1.5MB', '3 GB'
- parent-full-minibatch: '512', '10KB', '4MiB' (run 0)
- parent-full-minibatch:  (run 1)
- parent-full-minibatch: '10KB', '1kB', '2 gibibytes' (run 2)
- parent-full-minibatch: '4MiB', '1.5K', '10 kilobytes', '1 byte' (run 3)
- parent-full-minibatch: '10KB', '1.5K' (run 4)
- parent-full-minibatch: '512', '1kB', '1KiB' (run 5)
- parent-full-minibatch: '3 GB', '256Mi', '2 gibibytes' (run 6)
- parent-full-minibatch: '3 GB', '256Mi' (run 7)
- parent-full-minibatch: '10KB', '2 gibibytes' (run 8)
- parent-full-minibatch: '512', '1.5MB', '1.5K', '1,024' (run 9)
- seed-full-clustergold: '512', '10KB', '1.5MB', '3 GB', '1kB', '1KiB', '4MiB', '2Gi', '256Mi', '1.5K', '512m', '10 kilobytes', '1 byte', '2 gibibytes', '1,024'
- seed-full-first: '512', '10KB', '1.5MB', '3 GB'
- seed-full-minibatch: '10KB', '512m', '1,024' (run 0)
- seed-full-minibatch: '10 kilobytes' (run 1)
- seed-full-minibatch: '512m', '10 kilobytes', '1,024' (run 2)
- seed-full-minibatch: '2Gi', '10 kilobytes' (run 3)
- seed-full-minibatch: '10KB', '1kB', '2Gi' (run 4)
- seed-full-minibatch: '1kB', '1KiB', '1 byte' (run 5)
- seed-full-minibatch: '512m', '1 byte', '1,024' (run 6)
- seed-full-minibatch: '1KiB', '1.5K' (run 7)
- seed-full-minibatch: '1.5MB', '256Mi', '1,024' (run 8)
- seed-full-minibatch: '1.5MB', '512m' (run 9)

Mean [bootstrap 95% interval over runs].
