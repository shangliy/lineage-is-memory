Held-out best per run, and per label the share of proposals that get all search examples of the label right (first number) and the held-out best candidates that get all held-out examples right (second). Tokens exclude held-out scoring; to solve: median over runs that solved the search set.

| cell | runs | tokens / run | solved | tokens to solve | best chars | held-out best | payments | fulfillment | logistics | trust_safety | care | privacy |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| parent-full-clustergold | 10 | 50176 | 9/10 | 45558 | 2373 | 0.917 [0.892, 0.942] | 29/31, 10/10 | 23/31, 10/10 | 22/31, 1/10 | 26/31, 10/10 | 21/31, 10/10 | 22/31, 9/10 |
| parent-full-first | 10 | 40038 | 10/10 | 36617 | 2136 | 0.950 [0.925, 0.975] | 33/33, 10/10 | 21/33, 10/10 | 24/33, 4/10 | 33/33, 10/10 | 10/33, 10/10 | 23/33, 10/10 |
| parent-full-minibatch | 10 | 76164 | 3/10 | 50214 | 1648 | 0.758 [0.658, 0.850] | 49/62, 9/10 | 37/62, 6/10 | 41/62, 5/10 | 38/62, 7/10 | 44/62, 8/10 | 27/62, 6/10 |
| seed-full-clustergold | 10 | 86907 | 1/10 | 38817 | 1600 | 0.792 [0.733, 0.842] | 63/66, 10/10 | 15/66, 3/10 | 29/66, 2/10 | 58/66, 9/10 | 47/66, 9/10 | 16/66, 2/10 |
| seed-full-first | 10 | 59540 | 0/10 | - | 921 | 0.500 [0.500, 0.500] | 70/70, 10/10 | 0/70, 0/10 | 69/70, 10/10 | 70/70, 10/10 | 0/70, 0/10 | 0/70, 0/10 |
| seed-full-minibatch | 10 | 60018 | 0/10 | - | 1016 | 0.508 [0.425, 0.600] | 34/70, 5/10 | 36/70, 5/10 | 30/70, 4/10 | 26/70, 4/10 | 41/70, 5/10 | 13/70, 2/10 |
| seed-none | 10 | 88943 | 0/10 | - | 36 | 0.000 [0.000, 0.000] | 0/70, 0/10 | 0/70, 0/10 | 0/70, 0/10 | 0/70, 0/10 | 0/70, 0/10 | 0/70, 0/10 |

Wrong answers shown to the seed's first rewrite:

- parent-full-clustergold run 0: 
- parent-full-clustergold run 1: 
- parent-full-clustergold run 2: 
- parent-full-clustergold run 3: 
- parent-full-clustergold run 4: 
- parent-full-clustergold run 5: 
- parent-full-clustergold run 6: 
- parent-full-clustergold run 7: 
- parent-full-clustergold run 8: 
- parent-full-clustergold run 9: 
- parent-full-first run 0: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- parent-full-first run 1: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- parent-full-first run 2: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- parent-full-first run 3: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- parent-full-first run 4: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- parent-full-first run 5: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- parent-full-first run 6: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- parent-full-first run 7: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- parent-full-first run 8: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- parent-full-first run 9: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- parent-full-minibatch run 0: 'The mug arrived cracked, I want my money back.', 'My invoice shows a tax amount that looks wrong.', 'Delete my account and all my data.', 'Why did my promo code not apply at checkout?'
- parent-full-minibatch run 1: 'The mug arrived cracked, I want my money back.', "I can't log in after resetting my password.", 'Delete my account and all my data.', 'I have two accounts, can you combine them?'
- parent-full-minibatch run 2: "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password.", 'Why did my promo code not apply at checkout?', 'I have two accounts, can you combine them?'
- parent-full-minibatch run 3: "I can't log in after resetting my password.", 'Please cancel the subscription renewal that hit my card today.', 'How do I update the email on my profile?', 'Is Saturday delivery available?'
- parent-full-minibatch run 4: 'The mug arrived cracked, I want my money back.', 'Tracking says delivered but there is no parcel anywhere.', 'Someone logged into my account from another country.', 'Why did my promo code not apply at checkout?'
- parent-full-minibatch run 5: 'Wrong size shoes were delivered, how do I send them back?', 'How do I update the email on my profile?', 'Delete my account and all my data.', 'Is Saturday delivery available?'
- parent-full-minibatch run 6: 'I was charged twice for order 4471.', "I can't log in after resetting my password.", 'Can I change the delivery address for an order that shipped?', 'Someone logged into my account from another country.'
- parent-full-minibatch run 7: 'The mug arrived cracked, I want my money back.', 'Tracking says delivered but there is no parcel anywhere.', 'Delete my account and all my data.', 'Why did my promo code not apply at checkout?'
- parent-full-minibatch run 8: 'The mug arrived cracked, I want my money back.', 'Please cancel the subscription renewal that hit my card today.', 'Someone logged into my account from another country.', 'I have two accounts, can you combine them?'
- parent-full-minibatch run 9: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', 'Please cancel the subscription renewal that hit my card today.', 'Can I change the delivery address for an order that shipped?'
- seed-full-clustergold run 0: 
- seed-full-clustergold run 1: 
- seed-full-clustergold run 2: 
- seed-full-clustergold run 3: 
- seed-full-clustergold run 4: 
- seed-full-clustergold run 5: 
- seed-full-clustergold run 6: 
- seed-full-clustergold run 7: 
- seed-full-clustergold run 8: 
- seed-full-clustergold run 9: 
- seed-full-first run 0: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- seed-full-first run 1: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- seed-full-first run 2: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- seed-full-first run 3: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- seed-full-first run 4: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- seed-full-first run 5: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- seed-full-first run 6: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- seed-full-first run 7: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- seed-full-first run 8: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- seed-full-first run 9: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- seed-full-minibatch run 0: 'The mug arrived cracked, I want my money back.', 'My invoice shows a tax amount that looks wrong.', 'Delete my account and all my data.', 'Why did my promo code not apply at checkout?'
- seed-full-minibatch run 1: 'The mug arrived cracked, I want my money back.', "I can't log in after resetting my password.", 'Delete my account and all my data.', 'I have two accounts, can you combine them?'
- seed-full-minibatch run 2: "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password.", 'Why did my promo code not apply at checkout?', 'I have two accounts, can you combine them?'
- seed-full-minibatch run 3: "I can't log in after resetting my password.", 'Please cancel the subscription renewal that hit my card today.', 'How do I update the email on my profile?', 'Is Saturday delivery available?'
- seed-full-minibatch run 4: 'The mug arrived cracked, I want my money back.', 'Tracking says delivered but there is no parcel anywhere.', 'Someone logged into my account from another country.', 'Why did my promo code not apply at checkout?'
- seed-full-minibatch run 5: 'Wrong size shoes were delivered, how do I send them back?', 'How do I update the email on my profile?', 'Delete my account and all my data.', 'Is Saturday delivery available?'
- seed-full-minibatch run 6: 'I was charged twice for order 4471.', "I can't log in after resetting my password.", 'Can I change the delivery address for an order that shipped?', 'Someone logged into my account from another country.'
- seed-full-minibatch run 7: 'The mug arrived cracked, I want my money back.', 'Tracking says delivered but there is no parcel anywhere.', 'Delete my account and all my data.', 'Why did my promo code not apply at checkout?'
- seed-full-minibatch run 8: 'The mug arrived cracked, I want my money back.', 'Please cancel the subscription renewal that hit my card today.', 'Someone logged into my account from another country.', 'I have two accounts, can you combine them?'
- seed-full-minibatch run 9: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', 'Please cancel the subscription renewal that hit my card today.', 'Can I change the delivery address for an order that shipped?'

Mean [bootstrap 95% interval over runs].
