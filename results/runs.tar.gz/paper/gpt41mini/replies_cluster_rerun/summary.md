Held-out best per run, and per label the share of proposals that get all search examples of the label right (first number) and the held-out best candidates that get all held-out examples right (second). Tokens exclude held-out scoring; to solve: median over runs that solved the search set.

| cell | runs | tokens / run | solved | tokens to solve | best chars | held-out best | refund | password | late_order | cancel | bug | legal | feature | delete |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| parent-full-cluster | 10 | 67294 | 2/10 | 41162 | 1808 | 0.450 [0.250, 0.656] | 23/64, 5/10 | 19/64, 5/10 | 6/64, 2/10 | 22/64, 4/10 | 44/64, 6/10 | 5/64, 1/10 | 25/64, 3/10 | 19/64, 5/10 |

Wrong answers shown to the seed's first rewrite:

- parent-full-cluster run 0: 
- parent-full-cluster run 1: 
- parent-full-cluster run 2: 
- parent-full-cluster run 3: 
- parent-full-cluster run 4: 
- parent-full-cluster run 5: 
- parent-full-cluster run 6: 
- parent-full-cluster run 7: 
- parent-full-cluster run 8: 
- parent-full-cluster run 9: 

Mean [bootstrap 95% interval over runs].

Judge gpt-4.1-mini: 1477 calls, 344648 tokens.
