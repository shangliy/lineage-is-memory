Held-out best per run, and per label the share of proposals that get all search examples of the label right (first number) and the held-out best candidates that get all held-out examples right (second). Tokens exclude held-out scoring; to solve: median over runs that solved the search set.

| cell | runs | tokens / run | solved | tokens to solve | best chars | held-out best | payments | fulfillment | logistics | trust_safety | care | privacy |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| parent-full-cluster | 10 | 53381 | 2/10 | 43800 | 2379 | 0.783 [0.683, 0.867] | 48/67, 9/10 | 11/67, 3/10 | 37/67, 4/10 | 33/67, 8/10 | 20/67, 4/10 | 42/67, 10/10 |
| parent-full-diverse | 10 | 28829 | 5/10 | 28144 | 1512 | 0.858 [0.783, 0.917] | 53/66, 10/10 | 24/66, 6/10 | 49/66, 8/10 | 27/66, 9/10 | 16/66, 3/10 | 27/66, 7/10 |
| parent-full-first | 10 | 27729 | 9/10 | 27310 | 1512 | 0.925 [0.875, 0.975] | 53/57, 10/10 | 26/57, 9/10 | 46/57, 7/10 | 40/57, 9/10 | 18/57, 7/10 | 35/57, 10/10 |
| parent-full-minibatch | 10 | 28994 | 2/10 | 28738 | 1261 | 0.750 [0.642, 0.858] | 47/69, 8/10 | 16/69, 4/10 | 43/69, 8/10 | 28/69, 8/10 | 20/69, 2/10 | 21/69, 7/10 |
| seed-full-cluster | 10 | 32876 | 0/10 | - | 909 | 0.533 [0.442, 0.625] | 8/70, 9/10 | 2/70, 1/10 | 16/70, 4/10 | 12/70, 5/10 | 2/70, 0/10 | 9/70, 3/10 |
| seed-full-diverse | 10 | 17613 | 0/10 | - | 304 | 0.442 [0.417, 0.467] | 55/70, 10/10 | 6/70, 3/10 | 58/70, 10/10 | 0/70, 0/10 | 0/70, 0/10 | 0/70, 0/10 |
| seed-full-first | 10 | 17746 | 0/10 | - | 327 | 0.500 [0.467, 0.533] | 52/70, 10/10 | 16/70, 6/10 | 46/70, 5/10 | 20/70, 9/10 | 0/70, 0/10 | 0/70, 0/10 |
| seed-full-minibatch | 10 | 17804 | 0/10 | - | 354 | 0.500 [0.425, 0.583] | 25/70, 5/10 | 16/70, 5/10 | 22/70, 4/10 | 2/70, 5/10 | 2/70, 2/10 | 9/70, 4/10 |
| seed-none | 10 | 13133 | 0/10 | - | 36 | 0.000 [0.000, 0.000] | 0/70, 0/10 | 0/70, 0/10 | 0/70, 0/10 | 0/70, 0/10 | 0/70, 0/10 | 0/70, 0/10 |

Wrong answers shown to the seed's first rewrite:

- parent-full-cluster run 0: 
- parent-full-cluster run 1: 
- parent-full-cluster run 2: 
- parent-full-cluster run 3: 
- parent-full-cluster run 4: 
- parent-full-cluster run 5: 
- parent-full-cluster run 6: 
- parent-full-cluster run 7: 
- parent-full-cluster run 8: 
- parent-full-cluster run 9: 
- parent-full-diverse run 0: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- parent-full-diverse run 1: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- parent-full-diverse run 2: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- parent-full-diverse run 3: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- parent-full-diverse run 4: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- parent-full-diverse run 5: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- parent-full-diverse run 6: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- parent-full-diverse run 7: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- parent-full-diverse run 8: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- parent-full-diverse run 9: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- parent-full-first run 0: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- parent-full-first run 1: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- parent-full-first run 2: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- parent-full-first run 3: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- parent-full-first run 4: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- parent-full-first run 5: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- parent-full-first run 6: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- parent-full-first run 7: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- parent-full-first run 8: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- parent-full-first run 9: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- parent-full-minibatch run 0: 'The mug arrived cracked, I want my money back.', 'My invoice shows a tax amount that looks wrong.', 'Delete my account and all my data.', 'Why did my promo code not apply at checkout?'
- parent-full-minibatch run 1: 'The mug arrived cracked, I want my money back.', "I can't log in after resetting my password.", 'Delete my account and all my data.', 'I have two accounts, can you combine them?'
- parent-full-minibatch run 2: "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password.", 'Why did my promo code not apply at checkout?', 'I have two accounts, can you combine them?'
- parent-full-minibatch run 3: "I can't log in after resetting my password.", 'Please cancel the subscription renewal that hit my card today.', 'How do I update the email on my profile?', 'Is Saturday delivery available?'
- parent-full-minibatch run 4: 'The mug arrived cracked, I want my money back.', 'Tracking says delivered but there is no parcel anywhere.', 'Someone logged into my account from another country.', 'Why did my promo code not apply at checkout?'
- parent-full-minibatch run 5: 'Wrong size shoes were delivered, how do I send them back?', 'How do I update the email on my profile?', 'Delete my account and all my data.', 'Is Saturday delivery available?'
- parent-full-minibatch run 6: 'I was charged twice for order 4471.', "I can't log in after resetting my password.", 'Can I change the delivery address for an order that shipped?', 'Someone logged into my account from another country.'
- parent-full-minibatch run 7: 'The mug arrived cracked, I want my money back.', 'Tracking says delivered but there is no parcel anywhere.', 'Delete my account and all my data.', 'Why did my promo code not apply at checkout?'
- parent-full-minibatch run 8: 'The mug arrived cracked, I want my money back.', 'Please cancel the subscription renewal that hit my card today.', 'Someone logged into my account from another country.', 'I have two accounts, can you combine them?'
- parent-full-minibatch run 9: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', 'Please cancel the subscription renewal that hit my card today.', 'Can I change the delivery address for an order that shipped?'
- seed-full-cluster run 0: 
- seed-full-cluster run 1: 
- seed-full-cluster run 2: 
- seed-full-cluster run 3: 
- seed-full-cluster run 4: 
- seed-full-cluster run 5: 
- seed-full-cluster run 6: 
- seed-full-cluster run 7: 
- seed-full-cluster run 8: 
- seed-full-cluster run 9: 
- seed-full-diverse run 0: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- seed-full-diverse run 1: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- seed-full-diverse run 2: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- seed-full-diverse run 3: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- seed-full-diverse run 4: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- seed-full-diverse run 5: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- seed-full-diverse run 6: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- seed-full-diverse run 7: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- seed-full-diverse run 8: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- seed-full-diverse run 9: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- seed-full-first run 0: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- seed-full-first run 1: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- seed-full-first run 2: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- seed-full-first run 3: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- seed-full-first run 4: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- seed-full-first run 5: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- seed-full-first run 6: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- seed-full-first run 7: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- seed-full-first run 8: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- seed-full-first run 9: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- seed-full-minibatch run 0: 'The mug arrived cracked, I want my money back.', 'My invoice shows a tax amount that looks wrong.', 'Delete my account and all my data.', 'Why did my promo code not apply at checkout?'
- seed-full-minibatch run 1: 'The mug arrived cracked, I want my money back.', "I can't log in after resetting my password.", 'Delete my account and all my data.', 'I have two accounts, can you combine them?'
- seed-full-minibatch run 2: "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password.", 'Why did my promo code not apply at checkout?', 'I have two accounts, can you combine them?'
- seed-full-minibatch run 3: "I can't log in after resetting my password.", 'Please cancel the subscription renewal that hit my card today.', 'How do I update the email on my profile?', 'Is Saturday delivery available?'
- seed-full-minibatch run 4: 'The mug arrived cracked, I want my money back.', 'Tracking says delivered but there is no parcel anywhere.', 'Someone logged into my account from another country.', 'Why did my promo code not apply at checkout?'
- seed-full-minibatch run 5: 'Wrong size shoes were delivered, how do I send them back?', 'How do I update the email on my profile?', 'Delete my account and all my data.', 'Is Saturday delivery available?'
- seed-full-minibatch run 6: 'I was charged twice for order 4471.', "I can't log in after resetting my password.", 'Can I change the delivery address for an order that shipped?', 'Someone logged into my account from another country.'
- seed-full-minibatch run 7: 'The mug arrived cracked, I want my money back.', 'Tracking says delivered but there is no parcel anywhere.', 'Delete my account and all my data.', 'Why did my promo code not apply at checkout?'
- seed-full-minibatch run 8: 'The mug arrived cracked, I want my money back.', 'Please cancel the subscription renewal that hit my card today.', 'Someone logged into my account from another country.', 'I have two accounts, can you combine them?'
- seed-full-minibatch run 9: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', 'Please cancel the subscription renewal that hit my card today.', 'Can I change the delivery address for an order that shipped?'

Mean [bootstrap 95% interval over runs].
