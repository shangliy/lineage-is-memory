## duration

Coverage: share of proposals (first number) and of run-best candidates (second) that pass every held-out case of the category.

| cell | runs | tokens / run | solved | tokens to solve (median) | held-out best | clock | days/weeks | invalid | iso | number | units | words |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| parent-full-cluster | 10 | 19171 | 7/10 | 10998 | 0.975 [0.958, 0.992] | 62/64, 10/10 | 40/64, 10/10 | 25/64, 6/10 | 54/64, 10/10 | 40/64, 9/10 | 40/64, 9/10 | 28/64, 10/10 |
| parent-full-diverse | 10 | 12921 | 10/10 | 9997.0 | 0.971 [0.958, 0.983] | 51/51, 10/10 | 27/51, 10/10 | 7/51, 3/10 | 41/51, 10/10 | 48/51, 10/10 | 41/51, 10/10 | 25/51, 10/10 |
| parent-full-first | 10 | 15945 | 6/10 | 7350.0 | 0.963 [0.942, 0.983] | 49/69, 10/10 | 52/69, 10/10 | 10/69, 5/10 | 46/69, 10/10 | 57/69, 10/10 | 57/69, 9/10 | 34/69, 9/10 |
| parent-full-minibatch | 10 | 25449 | 1/10 | 13695 | 0.863 [0.821, 0.908] | 53/105, 6/10 | 57/105, 7/10 | 24/105, 3/10 | 74/105, 8/10 | 24/105, 4/10 | 90/105, 10/10 | 84/105, 10/10 |
| seed-full-cluster | 10 | 16604 | 0/10 | - | 0.637 [0.588, 0.692] | 93/110, 9/10 | 3/110, 2/10 | 1/110, 0/10 | 27/110, 4/10 | 12/110, 3/10 | 28/110, 5/10 | 6/110, 1/10 |
| seed-full-diverse | 10 | 15931 | 0/10 | - | 0.729 [0.713, 0.750] | 107/110, 10/10 | 1/110, 1/10 | 6/110, 0/10 | 26/110, 9/10 | 85/110, 10/10 | 87/110, 8/10 | 1/110, 1/10 |
| seed-full-first | 10 | 10299 | 0/10 | - | 0.562 [0.550, 0.575] | 0/110, 0/10 | 4/110, 3/10 | 0/110, 0/10 | 1/110, 0/10 | 3/110, 2/10 | 93/110, 10/10 | 0/110, 0/10 |
| seed-full-minibatch | 10 | 11969 | 0/10 | - | 0.625 [0.554, 0.704] | 31/110, 3/10 | 11/110, 2/10 | 50/110, 2/10 | 20/110, 3/10 | 19/110, 2/10 | 32/110, 8/10 | 11/110, 3/10 |
| seed-none | 10 | 6777 | 0/10 | - | 0.633 [0.583, 0.679] | 7/110, 3/10 | 2/110, 1/10 | 7/110, 1/10 | 2/110, 0/10 | 2/110, 1/10 | 41/110, 8/10 | 10/110, 7/10 |

Failures shown to the seed's first rewrite:

- parent-full-cluster: '90', '1h30m', '1h 30m 15s', '3d', '1w', '2 hours', '1 minute 30 seconds', '01:30:00', '2:05', 'PT1H30M', 'P1DT2H', '1x', '-5m'
- parent-full-diverse: '90', '1h 30m 15s', '01:30:00', 'PT1H30M'
- parent-full-first: '90', '1h30m', '1h 30m 15s', '3d'
- parent-full-minibatch: '3d' (run 0)
- parent-full-minibatch: '1h 30m 15s', '2:05' (run 1)
- parent-full-minibatch: '1h30m' (run 2)
- parent-full-minibatch: '1h 30m 15s', '1 minute 30 seconds' (run 3)
- parent-full-minibatch: '-5m' (run 4)
- parent-full-minibatch: 'PT1H30M' (run 5)
- parent-full-minibatch: '1h 30m 15s', '1w' (run 6)
- parent-full-minibatch: 'PT1H30M' (run 7)
- parent-full-minibatch:  (run 8)
- parent-full-minibatch: '2 hours', '2:05' (run 9)
- seed-full-cluster: '90', '1h30m', '1h 30m 15s', '3d', '1w', '2 hours', '1 minute 30 seconds', '01:30:00', '2:05', 'PT1H30M', 'P1DT2H', '1x', '-5m'
- seed-full-diverse: '90', '1h 30m 15s', '01:30:00', 'PT1H30M'
- seed-full-first: '90', '1h30m', '1h 30m 15s', '3d'
- seed-full-minibatch: 'PT1H30M' (run 0)
- seed-full-minibatch: 'PT1H30M', '-5m' (run 1)
- seed-full-minibatch: '1w', '2 hours', '1x' (run 2)
- seed-full-minibatch: '2 hours', '01:30:00', '2:05', 'P1DT2H' (run 3)
- seed-full-minibatch: '1h 30m 15s', '1w', 'PT1H30M' (run 4)
- seed-full-minibatch:  (run 5)
- seed-full-minibatch: '90' (run 6)
- seed-full-minibatch: '2 hours', '01:30:00' (run 7)
- seed-full-minibatch: '3d', '2 hours' (run 8)
- seed-full-minibatch: '90', '01:30:00' (run 9)

## size

Coverage: share of proposals (first number) and of run-best candidates (second) that pass every held-out case of the category.

| cell | runs | tokens / run | solved | tokens to solve (median) | held-out best | bytes | iec | invalid | letter | separator | si | words |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| parent-full-cluster | 10 | 15105 | 7/10 | 8347 | 0.942 [0.883, 1.000] | 56/60, 10/10 | 46/60, 10/10 | 60/60, 10/10 | 30/60, 8/10 | 57/60, 10/10 | 41/60, 8/10 | 31/60, 9/10 |
| parent-full-diverse | 10 | 6010 | 10/10 | 5583.0 | 0.988 [0.975, 1.000] | 31/33, 10/10 | 20/33, 10/10 | 33/33, 10/10 | 20/33, 10/10 | 31/33, 10/10 | 28/33, 10/10 | 11/33, 7/10 |
| parent-full-first | 10 | 8210 | 8/10 | 5196.5 | 0.929 [0.833, 1.000] | 48/48, 10/10 | 33/48, 10/10 | 48/48, 10/10 | 26/48, 10/10 | 8/48, 8/10 | 45/48, 7/10 | 10/48, 8/10 |
| parent-full-minibatch | 10 | 15545 | 4/10 | 6244.0 | 0.904 [0.829, 0.967] | 80/81, 10/10 | 59/81, 9/10 | 75/81, 9/10 | 38/81, 8/10 | 36/81, 7/10 | 71/81, 10/10 | 33/81, 7/10 |
| seed-full-cluster | 10 | 16611 | 0/10 | - | 0.812 [0.746, 0.867] | 106/110, 10/10 | 45/110, 4/10 | 104/110, 9/10 | 29/110, 9/10 | 95/110, 9/10 | 91/110, 9/10 | 39/110, 2/10 |
| seed-full-diverse | 10 | 13027 | 0/10 | - | 0.737 [0.696, 0.779] | 103/110, 10/10 | 43/110, 6/10 | 106/110, 9/10 | 8/110, 5/10 | 105/110, 10/10 | 102/110, 10/10 | 0/110, 0/10 |
| seed-full-first | 10 | 13031 | 0/10 | - | 0.767 [0.725, 0.808] | 107/110, 10/10 | 23/110, 4/10 | 109/110, 10/10 | 43/110, 9/10 | 0/110, 0/10 | 103/110, 10/10 | 0/110, 0/10 |
| seed-full-minibatch | 10 | 13164 | 0/10 | - | 0.804 [0.754, 0.850] | 95/110, 8/10 | 40/110, 5/10 | 110/110, 10/10 | 37/110, 8/10 | 20/110, 2/10 | 70/110, 8/10 | 20/110, 5/10 |
| seed-none | 10 | 7641 | 0/10 | - | 0.738 [0.683, 0.787] | 101/110, 9/10 | 31/110, 7/10 | 108/110, 10/10 | 93/110, 10/10 | 5/110, 1/10 | 10/110, 5/10 | 0/110, 0/10 |

Failures shown to the seed's first rewrite:

- parent-full-cluster: '512', '10KB', '1.5MB', '3 GB', '1kB', '1KiB', '4MiB', '2Gi', '256Mi', '1.5K', '512m', '10 kilobytes', '1 byte', '2 gibibytes', '1,024'
- parent-full-diverse: '512', '3 GB', '1KiB', '1,024'
- parent-full-first: '512', '10KB', '1.5MB', '3 GB'
- parent-full-minibatch: '512', '1KiB', '2Gi' (run 0)
- parent-full-minibatch: '10KB', '512m' (run 1)
- parent-full-minibatch: '1.5MB', '4MiB', '1 byte', '2 gibibytes' (run 2)
- parent-full-minibatch: '512', '10KB', '512m' (run 3)
- parent-full-minibatch: '1.5K', '512m' (run 4)
- parent-full-minibatch: '10KB', '1kB' (run 5)
- parent-full-minibatch: '4MiB', '256Mi', '1 byte' (run 6)
- parent-full-minibatch: '512m', '1 byte' (run 7)
- parent-full-minibatch: '1.5MB', '4MiB' (run 8)
- parent-full-minibatch: '512m' (run 9)
- seed-full-cluster: '512', '10KB', '1.5MB', '3 GB', '1kB', '1KiB', '4MiB', '2Gi', '256Mi', '1.5K', '512m', '10 kilobytes', '1 byte', '2 gibibytes', '1,024'
- seed-full-diverse: '512', '3 GB', '1KiB', '1,024'
- seed-full-first: '512', '10KB', '1.5MB', '3 GB'
- seed-full-minibatch: '512', '256Mi', '2 gibibytes' (run 0)
- seed-full-minibatch: '1kB', '1 byte', '1,024' (run 1)
- seed-full-minibatch: '10KB', '2 gibibytes' (run 2)
- seed-full-minibatch: '512', '2 gibibytes' (run 3)
- seed-full-minibatch: '512' (run 4)
- seed-full-minibatch: '512m', '10 kilobytes', '2 gibibytes' (run 5)
- seed-full-minibatch: '1.5MB' (run 6)
- seed-full-minibatch: '512', '1.5MB', '256Mi' (run 7)
- seed-full-minibatch: '4MiB', '1,024' (run 8)
- seed-full-minibatch: '1.5MB', '4MiB', '2Gi', '1 byte' (run 9)

Mean [bootstrap 95% interval over runs].
