Held-out best per run, and per label the share of proposals that get all search examples of the label right (first number) and the held-out best candidates that get all held-out examples right (second). Tokens exclude held-out scoring; to solve: median over runs that solved the search set.

| cell | runs | tokens / run | solved | tokens to solve | best chars | held-out best | iso_date | us_date | eu_date | time | ipv4 | ipv6 | mac_address | uuid | email | url | hex_color | semver |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| parent-full-cluster | 10 | 18043 | 9/10 | 13762 | 616 | 0.938 [0.900, 0.963] | 25/32, 10/10 | 24/32, 8/10 | 15/32, 9/10 | 14/32, 10/10 | 22/32, 10/10 | 21/32, 10/10 | 28/32, 9/10 | 22/32, 10/10 | 26/32, 1/10 | 25/32, 10/10 | 23/32, 10/10 | 21/32, 10/10 |
| parent-full-diverse | 10 | 18054 | 9/10 | 14404 | 551 | 0.942 [0.921, 0.967] | 31/37, 10/10 | 31/37, 7/10 | 20/37, 10/10 | 18/37, 10/10 | 22/37, 8/10 | 31/37, 10/10 | 37/37, 10/10 | 31/37, 10/10 | 33/37, 2/10 | 34/37, 10/10 | 25/37, 10/10 | 15/37, 9/10 |
| parent-full-first | 10 | 24990 | 7/10 | 21444 | 579 | 0.917 [0.883, 0.946] | 48/52, 9/10 | 47/52, 10/10 | 31/52, 10/10 | 30/52, 9/10 | 19/52, 10/10 | 19/52, 10/10 | 46/52, 9/10 | 38/52, 10/10 | 26/52, 1/10 | 41/52, 8/10 | 26/52, 9/10 | 21/52, 8/10 |
| parent-full-minibatch | 10 | 29990 | 5/10 | 22932 | 658 | 0.883 [0.833, 0.929] | 43/58, 10/10 | 50/58, 10/10 | 30/58, 7/10 | 29/58, 9/10 | 39/58, 9/10 | 42/58, 9/10 | 53/58, 10/10 | 48/58, 10/10 | 53/58, 0/10 | 50/58, 9/10 | 41/58, 8/10 | 22/58, 7/10 |
| seed-full-cluster | 10 | 32734 | 0/10 | - | 348 | 0.613 [0.533, 0.688] | 68/70, 10/10 | 41/70, 4/10 | 0/70, 0/10 | 0/70, 0/10 | 28/70, 4/10 | 23/70, 3/10 | 65/70, 10/10 | 25/70, 8/10 | 58/70, 1/10 | 55/70, 6/10 | 38/70, 7/10 | 55/70, 10/10 |
| seed-full-diverse | 10 | 26822 | 0/10 | - | 363 | 0.633 [0.592, 0.675] | 68/70, 10/10 | 51/70, 5/10 | 0/70, 0/10 | 0/70, 0/10 | 14/70, 7/10 | 58/70, 10/10 | 66/70, 10/10 | 35/70, 9/10 | 59/70, 0/10 | 57/70, 9/10 | 6/70, 3/10 | 0/70, 0/10 |
| seed-full-first | 10 | 27280 | 0/10 | - | 335 | 0.408 [0.367, 0.446] | 70/70, 10/10 | 67/70, 10/10 | 0/70, 0/10 | 0/70, 0/10 | 0/70, 0/10 | 0/70, 0/10 | 42/70, 9/10 | 16/70, 6/10 | 31/70, 0/10 | 26/70, 4/10 | 1/70, 0/10 | 0/70, 0/10 |
| seed-full-minibatch | 10 | 26524 | 0/10 | - | 333 | 0.554 [0.496, 0.608] | 32/70, 6/10 | 46/70, 6/10 | 13/70, 2/10 | 14/70, 2/10 | 11/70, 3/10 | 19/70, 3/10 | 66/70, 10/10 | 42/70, 9/10 | 43/70, 1/10 | 54/70, 6/10 | 11/70, 3/10 | 6/70, 3/10 |
| seed-none | 10 | 22931 | 0/10 | - | 263 | 0.279 [0.233, 0.329] | 9/70, 3/10 | 4/70, 1/10 | 0/70, 0/10 | 0/70, 1/10 | 1/70, 1/10 | 1/70, 1/10 | 37/70, 8/10 | 11/70, 5/10 | 24/70, 2/10 | 21/70, 4/10 | 2/70, 1/10 | 0/70, 0/10 |

Wrong answers shown to the seed's first rewrite:

- parent-full-cluster run 0: 
- parent-full-cluster run 1: 
- parent-full-cluster run 2: 
- parent-full-cluster run 3: 
- parent-full-cluster run 4: 
- parent-full-cluster run 5: 
- parent-full-cluster run 6: 
- parent-full-cluster run 7: 
- parent-full-cluster run 8: 
- parent-full-cluster run 9: 
- parent-full-diverse run 0: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- parent-full-diverse run 1: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- parent-full-diverse run 2: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- parent-full-diverse run 3: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- parent-full-diverse run 4: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- parent-full-diverse run 5: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- parent-full-diverse run 6: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- parent-full-diverse run 7: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- parent-full-diverse run 8: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- parent-full-diverse run 9: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- parent-full-first run 0: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- parent-full-first run 1: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- parent-full-first run 2: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- parent-full-first run 3: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- parent-full-first run 4: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- parent-full-first run 5: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- parent-full-first run 6: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- parent-full-first run 7: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- parent-full-first run 8: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- parent-full-first run 9: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- parent-full-minibatch run 0: '12/31/1999', '00:1A:2B:3C:4D:5E', 'a4:83:e7:0b:9c:12', '#FFF'
- parent-full-minibatch run 1: '1999-12-31', '03/15/2024', '14:05', 'j.smith+news@mail.co.uk'
- parent-full-minibatch run 2: '23:59:59', 'a4:83:e7:0b:9c:12', 'ana@example.com', 'http://localhost:8080'
- parent-full-minibatch run 3: '23:59:59', 'fe80::1ff:fe23:4567:890a', 'f47ac10b-58cc-4372-a567-0e02b2c3d479', 'j.smith+news@mail.co.uk'
- parent-full-minibatch run 4: '12/31/1999', 'a4:83:e7:0b:9c:12', 'http://localhost:8080', '2.0.0-rc.1'
- parent-full-minibatch run 5: '00:1A:2B:3C:4D:5E', 'a4:83:e7:0b:9c:12', 'f47ac10b-58cc-4372-a567-0e02b2c3d479', 'j.smith+news@mail.co.uk'
- parent-full-minibatch run 6: '1999-12-31', '23:59:59', 'fe80::1ff:fe23:4567:890a', '123e4567-e89b-12d3-a456-426614174000'
- parent-full-minibatch run 7: '1999-12-31', '31.12.1999', '8.8.8.8', 'http://localhost:8080'
- parent-full-minibatch run 8: '03/15/2024', '2001:db8::1', '123e4567-e89b-12d3-a456-426614174000', 'ana@example.com'
- parent-full-minibatch run 9: '2024-03-15', '03/15/2024', '31.12.1999', 'f47ac10b-58cc-4372-a567-0e02b2c3d479'
- seed-full-cluster run 0: 
- seed-full-cluster run 1: 
- seed-full-cluster run 2: 
- seed-full-cluster run 3: 
- seed-full-cluster run 4: 
- seed-full-cluster run 5: 
- seed-full-cluster run 6: 
- seed-full-cluster run 7: 
- seed-full-cluster run 8: 
- seed-full-cluster run 9: 
- seed-full-diverse run 0: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- seed-full-diverse run 1: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- seed-full-diverse run 2: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- seed-full-diverse run 3: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- seed-full-diverse run 4: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- seed-full-diverse run 5: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- seed-full-diverse run 6: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- seed-full-diverse run 7: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- seed-full-diverse run 8: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- seed-full-diverse run 9: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- seed-full-first run 0: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- seed-full-first run 1: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- seed-full-first run 2: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- seed-full-first run 3: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- seed-full-first run 4: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- seed-full-first run 5: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- seed-full-first run 6: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- seed-full-first run 7: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- seed-full-first run 8: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- seed-full-first run 9: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- seed-full-minibatch run 0: '12/31/1999', '00:1A:2B:3C:4D:5E', 'a4:83:e7:0b:9c:12', '#FFF'
- seed-full-minibatch run 1: '1999-12-31', '03/15/2024', '14:05', 'j.smith+news@mail.co.uk'
- seed-full-minibatch run 2: '23:59:59', 'a4:83:e7:0b:9c:12', 'ana@example.com', 'http://localhost:8080'
- seed-full-minibatch run 3: '23:59:59', 'fe80::1ff:fe23:4567:890a', 'f47ac10b-58cc-4372-a567-0e02b2c3d479', 'j.smith+news@mail.co.uk'
- seed-full-minibatch run 4: '12/31/1999', 'a4:83:e7:0b:9c:12', 'http://localhost:8080', '2.0.0-rc.1'
- seed-full-minibatch run 5: '00:1A:2B:3C:4D:5E', 'a4:83:e7:0b:9c:12', 'f47ac10b-58cc-4372-a567-0e02b2c3d479', 'j.smith+news@mail.co.uk'
- seed-full-minibatch run 6: '1999-12-31', '23:59:59', 'fe80::1ff:fe23:4567:890a', '123e4567-e89b-12d3-a456-426614174000'
- seed-full-minibatch run 7: '1999-12-31', '31.12.1999', '8.8.8.8', 'http://localhost:8080'
- seed-full-minibatch run 8: '03/15/2024', '2001:db8::1', '123e4567-e89b-12d3-a456-426614174000', 'ana@example.com'
- seed-full-minibatch run 9: '2024-03-15', '03/15/2024', '31.12.1999', 'f47ac10b-58cc-4372-a567-0e02b2c3d479'

Mean [bootstrap 95% interval over runs].
