Held-out best per run, and per label the share of proposals that get all search examples of the label right (first number) and the held-out best candidates that get all held-out examples right (second). Tokens exclude held-out scoring; to solve: median over runs that solved the search set.

| cell | runs | tokens / run | solved | tokens to solve | best chars | held-out best | iso | us_slash | eu_dot | long_us | long_eu | compact | slash_ymd | with_time | ordinal | short_year | weekday | invalid |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| parent-full-cluster | 10 | 13867 | 10/10 | 7156 | 490 | 0.979 [0.958, 0.996] | 21/21, 10/10 | 20/21, 10/10 | 17/21, 9/10 | 21/21, 10/10 | 21/21, 10/10 | 17/21, 7/10 | 17/21, 10/10 | 21/21, 10/10 | 21/21, 10/10 | 20/21, 10/10 | 21/21, 10/10 | 21/21, 10/10 |
| parent-full-diverse | 10 | 4725 | 10/10 | 4807 | 238 | 1.000 [1.000, 1.000] | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 |
| parent-full-first | 10 | 4492 | 10/10 | 4428 | 191 | 1.000 [1.000, 1.000] | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 |
| parent-full-minibatch | 10 | 4619 | 10/10 | 4429 | 209 | 0.992 [0.975, 1.000] | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 9/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 |
| seed-full-cluster | 10 | 25876 | 7/10 | 10809 | 471 | 0.988 [0.975, 1.000] | 43/43, 10/10 | 41/43, 10/10 | 10/43, 7/10 | 43/43, 10/10 | 43/43, 10/10 | 43/43, 10/10 | 43/43, 10/10 | 43/43, 10/10 | 43/43, 10/10 | 34/43, 10/10 | 43/43, 10/10 | 43/43, 10/10 |
| seed-full-diverse | 10 | 4768 | 10/10 | 4832 | 248 | 0.996 [0.988, 1.000] | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 9/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 |
| seed-full-first | 10 | 4479 | 10/10 | 4482 | 188 | 1.000 [1.000, 1.000] | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 |
| seed-full-minibatch | 10 | 4676 | 10/10 | 4640 | 219 | 0.996 [0.988, 1.000] | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 9/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 |
| seed-none | 10 | 4021 | 10/10 | 3837 | 152 | 1.000 [1.000, 1.000] | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 |

Wrong answers shown to the seed's first rewrite:

- parent-full-cluster run 0: 
- parent-full-cluster run 1: 
- parent-full-cluster run 2: 
- parent-full-cluster run 3: 
- parent-full-cluster run 4: 
- parent-full-cluster run 5: 
- parent-full-cluster run 6: '2024-03-05', '03/05/2024', '2024-03-05T14:30:00Z', '11/30/99', '2024-02-30'
- parent-full-cluster run 7: '2024-03-05', '03/05/2024', 'March 5, 2024', '2024-03-05T14:30:00Z', '2024-02-30', '13/45/2020'
- parent-full-cluster run 8: 
- parent-full-cluster run 9: 
- parent-full-diverse run 0: '2024-03-05', '2024-03-05T14:30:00Z', 'the 5th of March, 2024', 'Saturday, November 30, 2019'
- parent-full-diverse run 1: '2024-03-05', '2024-03-05T14:30:00Z', 'the 5th of March, 2024', 'Saturday, November 30, 2019'
- parent-full-diverse run 2: '2024-03-05', '2024-03-05T14:30:00Z', 'the 5th of March, 2024', 'Saturday, November 30, 2019'
- parent-full-diverse run 3: '2024-03-05', '2024-03-05T14:30:00Z', 'the 5th of March, 2024', 'Saturday, November 30, 2019'
- parent-full-diverse run 4: '2024-03-05', '2024-03-05T14:30:00Z', 'the 5th of March, 2024', 'Saturday, November 30, 2019'
- parent-full-diverse run 5: '2024-03-05', '2024-03-05T14:30:00Z', 'the 5th of March, 2024', 'Saturday, November 30, 2019'
- parent-full-diverse run 6: '2024-03-05', '2024-03-05T14:30:00Z', 'the 5th of March, 2024', 'Saturday, November 30, 2019'
- parent-full-diverse run 7: '2024-03-05', '2024-03-05T14:30:00Z', 'the 5th of March, 2024', 'Saturday, November 30, 2019'
- parent-full-diverse run 8: '2024-03-05', '2024-03-05T14:30:00Z', 'the 5th of March, 2024', 'Saturday, November 30, 2019'
- parent-full-diverse run 9: '2024-03-05', '2024-03-05T14:30:00Z', 'the 5th of March, 2024', 'Saturday, November 30, 2019'
- parent-full-first run 0: '2024-03-05', '2019-11-30', '03/05/2024', '11/30/2019'
- parent-full-first run 1: '2024-03-05', '2019-11-30', '03/05/2024', '11/30/2019'
- parent-full-first run 2: '2024-03-05', '2019-11-30', '03/05/2024', '11/30/2019'
- parent-full-first run 3: '2024-03-05', '2019-11-30', '03/05/2024', '11/30/2019'
- parent-full-first run 4: '2024-03-05', '2019-11-30', '03/05/2024', '11/30/2019'
- parent-full-first run 5: '2024-03-05', '2019-11-30', '03/05/2024', '11/30/2019'
- parent-full-first run 6: '2024-03-05', '2019-11-30', '03/05/2024', '11/30/2019'
- parent-full-first run 7: '2024-03-05', '2019-11-30', '03/05/2024', '11/30/2019'
- parent-full-first run 8: '2024-03-05', '2019-11-30', '03/05/2024', '11/30/2019'
- parent-full-first run 9: '2024-03-05', '2019-11-30', '03/05/2024', '11/30/2019'
- parent-full-minibatch run 0: '11/30/2019', '2024/03/05', '2019/11/30', 'Saturday, November 30, 2019'
- parent-full-minibatch run 1: '2019-11-30', '03/05/2024', 'March 5, 2024', '30th November 2019'
- parent-full-minibatch run 2: 'November 30, 2019', '2019/11/30', 'the 5th of March, 2024', '11/30/99'
- parent-full-minibatch run 3: 'November 30, 2019', '20191130', '2019-11-30 23:59', '30th November 2019'
- parent-full-minibatch run 4: '11/30/2019', '2019/11/30', '11/30/99', '13/45/2020'
- parent-full-minibatch run 5: '2024/03/05', '2019/11/30', '2019-11-30 23:59', '30th November 2019'
- parent-full-minibatch run 6: '2019-11-30', 'November 30, 2019', '20191130', '2024-03-05T14:30:00Z'
- parent-full-minibatch run 7: '2019-11-30', '30.11.2019', '30 Nov 2019', '11/30/99'
- parent-full-minibatch run 8: '03/05/2024', '20240305', '2024-03-05T14:30:00Z', 'the 5th of March, 2024'
- parent-full-minibatch run 9: '2024-03-05', '03/05/2024', '30.11.2019', '2019-11-30 23:59'
- seed-full-cluster run 0: 
- seed-full-cluster run 1: 
- seed-full-cluster run 2: 
- seed-full-cluster run 3: 
- seed-full-cluster run 4: 
- seed-full-cluster run 5: 
- seed-full-cluster run 6: 
- seed-full-cluster run 7: 
- seed-full-cluster run 8: 
- seed-full-cluster run 9: 
- seed-full-diverse run 0: '2024-03-05', '2024-03-05T14:30:00Z', 'the 5th of March, 2024', 'Saturday, November 30, 2019'
- seed-full-diverse run 1: '2024-03-05', '2024-03-05T14:30:00Z', 'the 5th of March, 2024', 'Saturday, November 30, 2019'
- seed-full-diverse run 2: '2024-03-05', '2024-03-05T14:30:00Z', 'the 5th of March, 2024', 'Saturday, November 30, 2019'
- seed-full-diverse run 3: '2024-03-05', '2024-03-05T14:30:00Z', 'the 5th of March, 2024', 'Saturday, November 30, 2019'
- seed-full-diverse run 4: '2024-03-05', '2024-03-05T14:30:00Z', 'the 5th of March, 2024', 'Saturday, November 30, 2019'
- seed-full-diverse run 5: '2024-03-05', '2024-03-05T14:30:00Z', 'the 5th of March, 2024', 'Saturday, November 30, 2019'
- seed-full-diverse run 6: '2024-03-05', '2024-03-05T14:30:00Z', 'the 5th of March, 2024', 'Saturday, November 30, 2019'
- seed-full-diverse run 7: '2024-03-05', '2024-03-05T14:30:00Z', 'the 5th of March, 2024', 'Saturday, November 30, 2019'
- seed-full-diverse run 8: '2024-03-05', '2024-03-05T14:30:00Z', 'the 5th of March, 2024', 'Saturday, November 30, 2019'
- seed-full-diverse run 9: '2024-03-05', '2024-03-05T14:30:00Z', 'the 5th of March, 2024', 'Saturday, November 30, 2019'
- seed-full-first run 0: '2024-03-05', '2019-11-30', '03/05/2024', '11/30/2019'
- seed-full-first run 1: '2024-03-05', '2019-11-30', '03/05/2024', '11/30/2019'
- seed-full-first run 2: '2024-03-05', '2019-11-30', '03/05/2024', '11/30/2019'
- seed-full-first run 3: '2024-03-05', '2019-11-30', '03/05/2024', '11/30/2019'
- seed-full-first run 4: '2024-03-05', '2019-11-30', '03/05/2024', '11/30/2019'
- seed-full-first run 5: '2024-03-05', '2019-11-30', '03/05/2024', '11/30/2019'
- seed-full-first run 6: '2024-03-05', '2019-11-30', '03/05/2024', '11/30/2019'
- seed-full-first run 7: '2024-03-05', '2019-11-30', '03/05/2024', '11/30/2019'
- seed-full-first run 8: '2024-03-05', '2019-11-30', '03/05/2024', '11/30/2019'
- seed-full-first run 9: '2024-03-05', '2019-11-30', '03/05/2024', '11/30/2019'
- seed-full-minibatch run 0: '11/30/2019', '2024/03/05', '2019/11/30', 'Saturday, November 30, 2019'
- seed-full-minibatch run 1: '2019-11-30', '03/05/2024', 'March 5, 2024', '30th November 2019'
- seed-full-minibatch run 2: 'November 30, 2019', '2019/11/30', 'the 5th of March, 2024', '11/30/99'
- seed-full-minibatch run 3: 'November 30, 2019', '20191130', '2019-11-30 23:59', '30th November 2019'
- seed-full-minibatch run 4: '11/30/2019', '2019/11/30', '11/30/99', '13/45/2020'
- seed-full-minibatch run 5: '2024/03/05', '2019/11/30', '2019-11-30 23:59', '30th November 2019'
- seed-full-minibatch run 6: '2019-11-30', 'November 30, 2019', '20191130', '2024-03-05T14:30:00Z'
- seed-full-minibatch run 7: '2019-11-30', '30.11.2019', '30 Nov 2019', '11/30/99'
- seed-full-minibatch run 8: '03/05/2024', '20240305', '2024-03-05T14:30:00Z', 'the 5th of March, 2024'
- seed-full-minibatch run 9: '2024-03-05', '03/05/2024', '30.11.2019', '2019-11-30 23:59'

Mean [bootstrap 95% interval over runs].
