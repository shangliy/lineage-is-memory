## duration

Coverage: share of proposals (first number) and of run-best candidates (second) that pass every held-out case of the category.

| cell | runs | tokens / run | solved | tokens to solve (median) | held-out best | clock | days/weeks | invalid | iso | number | units | words |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| seed-full-iso | 10 | 12090 | 0/10 | - | 0.633 [0.604, 0.671] | 0/110, 0/10 | 2/110, 1/10 | 1/110, 0/10 | 8/110, 3/10 | 30/110, 8/10 | 106/110, 10/10 | 1/110, 0/10 |
| seed-full-random | 10 | 15404 | 0/10 | - | 0.742 [0.696, 0.779] | 71/110, 7/10 | 14/110, 2/10 | 14/110, 0/10 | 57/110, 6/10 | 28/110, 7/10 | 52/110, 9/10 | 34/110, 4/10 |

Failures shown to the seed's first rewrite:

- seed-full-iso: '90', '1h30m', '1h 30m 15s', 'PT1H30M'
- seed-full-random: '2 hours', '01:30:00', '-5m', '90' (run 0)
- seed-full-random: 'P1DT2H', '1 minute 30 seconds', '2:05', 'PT1H30M' (run 1)
- seed-full-random: '1 minute 30 seconds', '-5m', '1h 30m 15s', '2:05' (run 2)
- seed-full-random: '1w', 'PT1H30M', '1 minute 30 seconds', '2 hours' (run 3)
- seed-full-random: '3d', '90', '2 hours', '1w' (run 4)
- seed-full-random: '1h30m', '01:30:00', '3d', '2 hours' (run 5)
- seed-full-random: '3d', '01:30:00', 'PT1H30M', '1h30m' (run 6)
- seed-full-random: '2:05', '1h 30m 15s', '01:30:00', 'P1DT2H' (run 7)
- seed-full-random: '1h30m', '-5m', 'PT1H30M', '3d' (run 8)
- seed-full-random: '2 hours', '01:30:00', 'P1DT2H', '90' (run 9)

Mean [bootstrap 95% interval over runs].
