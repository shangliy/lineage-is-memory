Held-out best per run, and per label the share of proposals that get all search examples of the label right (first number) and the held-out best candidates that get all held-out examples right (second). Tokens exclude held-out scoring; to solve: median over runs that solved the search set.

| cell | runs | tokens / run | solved | tokens to solve | best chars | held-out best | automatic_top_up | transfer_into_account | get_disposable_virtual_card | receiving_money | passcode_forgotten | transfer_fee_charged | pending_transfer | reverted_card_payment? | top_up_reverted | exchange_rate | declined_cash_withdrawal | topping_up_by_card |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| parent-full-first | 10 | 51028 | 1/10 | 64561 | 1230 | 0.856 [0.811, 0.897] | 68/69, 10/10 | 66/69, 1/10 | 63/69, 9/10 | 38/69, 8/10 | 54/69, 9/10 | 21/69, 10/10 | 59/69, 10/10 | 5/69, 0/10 | 43/69, 10/10 | 46/69, 10/10 | 43/69, 10/10 | 10/69, 4/10 |
| seed-full-first | 10 | 34313 | 0/10 | - | 575 | 0.317 [0.303, 0.331] | 61/70, 10/10 | 67/70, 7/10 | 63/70, 9/10 | 24/70, 9/10 | 0/70, 0/10 | 0/70, 0/10 | 0/70, 0/10 | 0/70, 0/10 | 0/70, 0/10 | 0/70, 0/10 | 0/70, 0/10 | 0/70, 0/10 |

Wrong answers shown to the seed's first rewrite:

- parent-full-first run 0: 'Does the app top up automatically?', 'I have an account at another bank, but I want to transfer some of the money to my account here.\n.', 'How can I create a disposable virtual card?', 'Will my GPB update my salary'
- parent-full-first run 1: 'Does the app top up automatically?', 'I have an account at another bank, but I want to transfer some of the money to my account here.\n.', 'How can I create a disposable virtual card?', 'Will my GPB update my salary'
- parent-full-first run 2: 'Does the app top up automatically?', 'I have an account at another bank, but I want to transfer some of the money to my account here.\n.', 'How can I create a disposable virtual card?', 'Will my GPB update my salary'
- parent-full-first run 3: 'Does the app top up automatically?', 'I have an account at another bank, but I want to transfer some of the money to my account here.\n.', 'How can I create a disposable virtual card?', 'Will my GPB update my salary'
- parent-full-first run 4: 'Does the app top up automatically?', 'I have an account at another bank, but I want to transfer some of the money to my account here.\n.', 'How can I create a disposable virtual card?', 'Will my GPB update my salary'
- parent-full-first run 5: 'Does the app top up automatically?', 'I have an account at another bank, but I want to transfer some of the money to my account here.\n.', 'How can I create a disposable virtual card?', 'Will my GPB update my salary'
- parent-full-first run 6: 'Does the app top up automatically?', 'I have an account at another bank, but I want to transfer some of the money to my account here.\n.', 'How can I create a disposable virtual card?', 'Will my GPB update my salary'
- parent-full-first run 7: 'Does the app top up automatically?', 'I have an account at another bank, but I want to transfer some of the money to my account here.\n.', 'How can I create a disposable virtual card?', 'Will my GPB update my salary'
- parent-full-first run 8: 'Does the app top up automatically?', 'I have an account at another bank, but I want to transfer some of the money to my account here.\n.', 'How can I create a disposable virtual card?', 'Will my GPB update my salary'
- parent-full-first run 9: 'Does the app top up automatically?', 'I have an account at another bank, but I want to transfer some of the money to my account here.\n.', 'How can I create a disposable virtual card?', 'Will my GPB update my salary'
- seed-full-first run 0: 'Does the app top up automatically?', 'I have an account at another bank, but I want to transfer some of the money to my account here.\n.', 'How can I create a disposable virtual card?', 'Will my GPB update my salary'
- seed-full-first run 1: 'Does the app top up automatically?', 'I have an account at another bank, but I want to transfer some of the money to my account here.\n.', 'How can I create a disposable virtual card?', 'Will my GPB update my salary'
- seed-full-first run 2: 'Does the app top up automatically?', 'I have an account at another bank, but I want to transfer some of the money to my account here.\n.', 'How can I create a disposable virtual card?', 'Will my GPB update my salary'
- seed-full-first run 3: 'Does the app top up automatically?', 'I have an account at another bank, but I want to transfer some of the money to my account here.\n.', 'How can I create a disposable virtual card?', 'Will my GPB update my salary'
- seed-full-first run 4: 'Does the app top up automatically?', 'I have an account at another bank, but I want to transfer some of the money to my account here.\n.', 'How can I create a disposable virtual card?', 'Will my GPB update my salary'
- seed-full-first run 5: 'Does the app top up automatically?', 'I have an account at another bank, but I want to transfer some of the money to my account here.\n.', 'How can I create a disposable virtual card?', 'Will my GPB update my salary'
- seed-full-first run 6: 'Does the app top up automatically?', 'I have an account at another bank, but I want to transfer some of the money to my account here.\n.', 'How can I create a disposable virtual card?', 'Will my GPB update my salary'
- seed-full-first run 7: 'Does the app top up automatically?', 'I have an account at another bank, but I want to transfer some of the money to my account here.\n.', 'How can I create a disposable virtual card?', 'Will my GPB update my salary'
- seed-full-first run 8: 'Does the app top up automatically?', 'I have an account at another bank, but I want to transfer some of the money to my account here.\n.', 'How can I create a disposable virtual card?', 'Will my GPB update my salary'
- seed-full-first run 9: 'Does the app top up automatically?', 'I have an account at another bank, but I want to transfer some of the money to my account here.\n.', 'How can I create a disposable virtual card?', 'Will my GPB update my salary'

Mean [bootstrap 95% interval over runs].
