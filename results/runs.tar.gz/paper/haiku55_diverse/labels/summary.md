Held-out best per run, and per label the share of proposals that get all search examples of the label right (first number) and the held-out best candidates that get all held-out examples right (second). Tokens exclude held-out scoring; to solve: median over runs that solved the search set.

| cell | runs | tokens / run | solved | tokens to solve | best chars | held-out best | iso_date | us_date | eu_date | time | ipv4 | ipv6 | mac_address | uuid | email | url | hex_color | semver |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| parent-full-diverse | 10 | 53615 | 8/10 | 43826 | 1445 | 0.925 [0.863, 0.975] | 33/37, 9/10 | 30/37, 6/10 | 20/37, 8/10 | 22/37, 9/10 | 29/37, 10/10 | 29/37, 10/10 | 35/37, 9/10 | 37/37, 10/10 | 30/37, 10/10 | 37/37, 10/10 | 34/37, 5/10 | 17/37, 9/10 |
| seed-full-diverse | 10 | 74296 | 0/10 | - | 766 | 0.871 [0.829, 0.908] | 62/70, 10/10 | 65/70, 6/10 | 18/70, 7/10 | 3/70, 4/10 | 64/70, 10/10 | 63/70, 10/10 | 69/70, 10/10 | 70/70, 10/10 | 63/70, 10/10 | 69/70, 10/10 | 66/70, 8/10 | 15/70, 2/10 |

Wrong answers shown to the seed's first rewrite:

- parent-full-diverse run 0: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- parent-full-diverse run 1: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- parent-full-diverse run 2: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- parent-full-diverse run 3: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- parent-full-diverse run 4: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- parent-full-diverse run 5: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- parent-full-diverse run 6: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- parent-full-diverse run 7: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- parent-full-diverse run 8: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- parent-full-diverse run 9: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- seed-full-diverse run 0: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- seed-full-diverse run 1: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- seed-full-diverse run 2: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- seed-full-diverse run 3: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- seed-full-diverse run 4: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- seed-full-diverse run 5: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- seed-full-diverse run 6: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- seed-full-diverse run 7: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- seed-full-diverse run 8: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'
- seed-full-diverse run 9: '2024-03-15', 'fe80::1ff:fe23:4567:890a', '00:1A:2B:3C:4D:5E', 'j.smith+news@mail.co.uk'

Mean [bootstrap 95% interval over runs].
