Held-out best per run, and per label the share of proposals that get all search examples of the label right (first number) and the held-out best candidates that get all held-out examples right (second). Tokens exclude held-out scoring; to solve: median over runs that solved the search set.

| cell | runs | tokens / run | solved | tokens to solve | best chars | held-out best | payments | fulfillment | logistics | trust_safety | care | privacy |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| parent-full-diverse | 10 | 52742 | 9/10 | 39457 | 2013 | 0.942 [0.908, 0.975] | 43/43, 10/10 | 17/43, 9/10 | 28/43, 4/10 | 33/43, 10/10 | 27/43, 10/10 | 33/43, 10/10 |
| seed-full-diverse | 10 | 59454 | 0/10 | - | 866 | 0.400 [0.375, 0.417] | 70/70, 10/10 | 0/70, 0/10 | 70/70, 9/10 | 0/70, 0/10 | 0/70, 0/10 | 0/70, 0/10 |

Wrong answers shown to the seed's first rewrite:

- parent-full-diverse run 0: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- parent-full-diverse run 1: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- parent-full-diverse run 2: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- parent-full-diverse run 3: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- parent-full-diverse run 4: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- parent-full-diverse run 5: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- parent-full-diverse run 6: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- parent-full-diverse run 7: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- parent-full-diverse run 8: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- parent-full-diverse run 9: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- seed-full-diverse run 0: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- seed-full-diverse run 1: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- seed-full-diverse run 2: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- seed-full-diverse run 3: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- seed-full-diverse run 4: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- seed-full-diverse run 5: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- seed-full-diverse run 6: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- seed-full-diverse run 7: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- seed-full-diverse run 8: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'
- seed-full-diverse run 9: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", 'Wrong size shoes were delivered, how do I send them back?'

Mean [bootstrap 95% interval over runs].
