## duration

Coverage: share of proposals (first number) and of run-best candidates (second) that pass every held-out case of the category.

| cell | runs | tokens / run | solved | tokens to solve (median) | held-out best | clock | days/weeks | invalid | iso | number | units | words |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| parent-full-diverse | 10 | 9205 | 10/10 | 8429.5 | 1.000 [1.000, 1.000] | 20/20, 10/10 | 11/20, 10/10 | 11/20, 10/10 | 20/20, 10/10 | 20/20, 10/10 | 20/20, 10/10 | 19/20, 10/10 |
| seed-full-diverse | 10 | 49779 | 0/10 | - | 0.942 [0.925, 0.958] | 107/109, 10/10 | 3/109, 3/10 | 22/109, 5/10 | 107/109, 10/10 | 109/109, 10/10 | 107/109, 10/10 | 71/109, 9/10 |

Failures shown to the seed's first rewrite:

- parent-full-diverse: '90', '1h 30m 15s', '01:30:00', 'PT1H30M'
- seed-full-diverse: '90', '1h 30m 15s', '01:30:00', 'PT1H30M'

## size

Coverage: share of proposals (first number) and of run-best candidates (second) that pass every held-out case of the category.

| cell | runs | tokens / run | solved | tokens to solve (median) | held-out best | bytes | iec | invalid | letter | separator | si | words |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| parent-full-diverse | 10 | 5601 | 10/10 | 5632.0 | 1.000 [1.000, 1.000] | 20/20, 10/10 | 12/20, 10/10 | 20/20, 10/10 | 20/20, 10/10 | 20/20, 10/10 | 20/20, 10/10 | 10/20, 10/10 |
| seed-full-diverse | 10 | 28927 | 0/10 | - | 0.879 [0.867, 0.892] | 109/109, 10/10 | 29/109, 9/10 | 109/109, 10/10 | 109/109, 10/10 | 108/109, 10/10 | 109/109, 10/10 | 0/109, 0/10 |

Failures shown to the seed's first rewrite:

- parent-full-diverse: '512', '3 GB', '1KiB', '1,024'
- seed-full-diverse: '512', '3 GB', '1KiB', '1,024'

Mean [bootstrap 95% interval over runs].
