Held-out best per run, and per label the share of proposals that get all search examples of the label right (first number) and the held-out best candidates that get all held-out examples right (second). Tokens exclude held-out scoring; to solve: median over runs that solved the search set.

| cell | runs | tokens / run | solved | tokens to solve | best chars | held-out best | iso_date | us_date | eu_date | time | ipv4 | ipv6 | mac_address | uuid | email | url | hex_color | semver |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| parent-full-clustergold | 10 | 31462 | 3/10 | 19234 | 480 | 0.858 [0.783, 0.925] | 46/63, 8/10 | 44/63, 10/10 | 24/63, 9/10 | 19/63, 6/10 | 38/63, 9/10 | 36/63, 9/10 | 59/63, 9/10 | 53/63, 10/10 | 43/63, 0/10 | 59/63, 7/10 | 50/63, 10/10 | 37/63, 9/10 |
| parent-full-first | 10 | 24734 | 5/10 | 18846 | 454 | 0.904 [0.833, 0.963] | 54/57, 9/10 | 52/57, 7/10 | 32/57, 8/10 | 25/57, 9/10 | 25/57, 10/10 | 25/57, 10/10 | 49/57, 10/10 | 39/57, 10/10 | 31/57, 1/10 | 43/57, 9/10 | 29/57, 9/10 | 16/57, 10/10 |
| seed-full-clustergold | 10 | 30072 | 0/10 | - | 274 | 0.596 [0.529, 0.671] | 56/70, 9/10 | 32/70, 7/10 | 1/70, 0/10 | 0/70, 0/10 | 38/70, 7/10 | 24/70, 6/10 | 51/70, 10/10 | 13/70, 7/10 | 44/70, 0/10 | 35/70, 5/10 | 19/70, 4/10 | 14/70, 3/10 |
| seed-full-first | 10 | 24848 | 0/10 | - | 266 | 0.383 [0.358, 0.412] | 65/70, 10/10 | 63/70, 10/10 | 0/70, 0/10 | 0/70, 0/10 | 0/70, 0/10 | 0/70, 0/10 | 49/70, 8/10 | 6/70, 3/10 | 33/70, 2/10 | 32/70, 0/10 | 0/70, 0/10 | 0/70, 0/10 |
| seed-none | 10 | 20189 | 0/10 | - | 84 | 0.279 [0.250, 0.337] | 3/70, 2/10 | 1/70, 1/10 | 0/70, 0/10 | 0/70, 8/10 | 0/70, 0/10 | 0/70, 0/10 | 7/70, 1/10 | 1/70, 9/10 | 2/70, 2/10 | 5/70, 9/10 | 0/70, 0/10 | 0/70, 0/10 |

Wrong answers shown to the seed's first rewrite:

- parent-full-clustergold run 0: '2024-03-15', '192.168.1.10', 'ana@example.com'
- parent-full-clustergold run 1: 
- parent-full-clustergold run 2: '2024-03-15', 'j.smith+news@mail.co.uk'
- parent-full-clustergold run 3: '2024-03-15', '192.168.1.10', 'j.smith+news@mail.co.uk'
- parent-full-clustergold run 4: '2024-03-15', '8.8.8.8', '#1a2b3c'
- parent-full-clustergold run 5: '2024-03-15', '8.8.8.8', 'j.smith+news@mail.co.uk'
- parent-full-clustergold run 6: '2024-03-15', '8.8.8.8'
- parent-full-clustergold run 7: '2024-03-15', '00:1A:2B:3C:4D:5E', '#FFF'
- parent-full-clustergold run 8: '12/31/1999', '2.0.0-rc.1'
- parent-full-clustergold run 9: '2024-03-15', '8.8.8.8', 'ana@example.com'
- parent-full-first run 0: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- parent-full-first run 1: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- parent-full-first run 2: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- parent-full-first run 3: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- parent-full-first run 4: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- parent-full-first run 5: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- parent-full-first run 6: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- parent-full-first run 7: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- parent-full-first run 8: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- parent-full-first run 9: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- seed-full-clustergold run 0: '2024-03-15', '192.168.1.10', 'ana@example.com'
- seed-full-clustergold run 1: 
- seed-full-clustergold run 2: '8.8.8.8', 'j.smith+news@mail.co.uk'
- seed-full-clustergold run 3: 
- seed-full-clustergold run 4: 
- seed-full-clustergold run 5: 
- seed-full-clustergold run 6: '2024-03-15', '8.8.8.8'
- seed-full-clustergold run 7: 
- seed-full-clustergold run 8: '2024-03-15', '8.8.8.8', '2.0.0-rc.1'
- seed-full-clustergold run 9: '2024-03-15', 'j.smith+news@mail.co.uk', '2.0.0-rc.1'
- seed-full-first run 0: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- seed-full-first run 1: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- seed-full-first run 2: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- seed-full-first run 3: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- seed-full-first run 4: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- seed-full-first run 5: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- seed-full-first run 6: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- seed-full-first run 7: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- seed-full-first run 8: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'
- seed-full-first run 9: '2024-03-15', '1999-12-31', '03/15/2024', '12/31/1999'

Mean [bootstrap 95% interval over runs].
