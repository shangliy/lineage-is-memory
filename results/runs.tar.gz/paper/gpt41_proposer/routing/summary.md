Held-out best per run, and per label the share of proposals that get all search examples of the label right (first number) and the held-out best candidates that get all held-out examples right (second). Tokens exclude held-out scoring; to solve: median over runs that solved the search set.

| cell | runs | tokens / run | solved | tokens to solve | best chars | held-out best | payments | fulfillment | logistics | trust_safety | care | privacy |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| parent-full-clustergold | 10 | 34474 | 3/10 | 33344 | 1200 | 0.792 [0.708, 0.850] | 57/68, 10/10 | 35/68, 7/10 | 37/68, 3/10 | 41/68, 9/10 | 10/68, 1/10 | 22/68, 7/10 |
| parent-full-first | 10 | 21225 | 6/10 | 18776 | 1108 | 0.892 [0.833, 0.942] | 51/52, 10/10 | 26/52, 7/10 | 38/52, 6/10 | 28/52, 9/10 | 17/52, 7/10 | 29/52, 9/10 |
| seed-full-clustergold | 10 | 23532 | 0/10 | - | 379 | 0.617 [0.492, 0.733] | 48/70, 10/10 | 36/70, 5/10 | 23/70, 3/10 | 13/70, 7/10 | 3/70, 0/10 | 15/70, 5/10 |
| seed-full-first | 10 | 17142 | 0/10 | - | 283 | 0.500 [0.467, 0.533] | 60/70, 10/10 | 19/70, 7/10 | 51/70, 3/10 | 24/70, 10/10 | 0/70, 0/10 | 0/70, 0/10 |
| seed-none | 10 | 13124 | 0/10 | - | 36 | 0.000 [0.000, 0.000] | 0/70, 0/10 | 0/70, 0/10 | 0/70, 0/10 | 0/70, 0/10 | 0/70, 0/10 | 0/70, 0/10 |

Wrong answers shown to the seed's first rewrite:

- parent-full-clustergold run 0: 'The mug arrived cracked, I want my money back.', 'I was charged twice for order 4471.', 'I can't log in after resetting my password.'
- parent-full-clustergold run 1: 'I was charged twice for order 4471.', "I can't log in after resetting my password.", 'Do you sell gift cards?'
- parent-full-clustergold run 2: "Where is my package? Tracking hasn't moved in 5 days.", 'The mug arrived cracked, I want my money back.', "I can't log in after resetting my password."
- parent-full-clustergold run 3: 
- parent-full-clustergold run 4: 'I was charged twice for order 4471.', "Where is my package? Tracking hasn't moved in 5 days.", 'How do I update the email on my profile?', 'The mug arrived cracked, I want my money back.', 'Do you sell gift cards?'
- parent-full-clustergold run 5: 'The mug arrived cracked, I want my money back.', 'I was charged twice for order 4471.', "I can't log in after resetting my password.", 'Do you sell gift cards?'
- parent-full-clustergold run 6: 'Tracking says delivered but there is no parcel anywhere.', 'How do I update the email on my profile?'
- parent-full-clustergold run 7: 'I was charged twice for order 4471.', 'How do I update the email on my profile?', 'Do you sell gift cards?'
- parent-full-clustergold run 8: 'I was charged twice for order 4471.', "Where is my package? Tracking hasn't moved in 5 days.", 'How do I update the email on my profile?', 'Do you sell gift cards?'
- parent-full-clustergold run 9: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "How do I update the email on my profile?", 'Do you sell gift cards?'
- parent-full-first run 0: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- parent-full-first run 1: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- parent-full-first run 2: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- parent-full-first run 3: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- parent-full-first run 4: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- parent-full-first run 5: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- parent-full-first run 6: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- parent-full-first run 7: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- parent-full-first run 8: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- parent-full-first run 9: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- seed-full-clustergold run 0: 'I was charged twice for order 4471.'
- seed-full-clustergold run 1: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password.", 'Do you sell gift cards?'
- seed-full-clustergold run 2: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password.", 'How do I update the email on my profile?', 'Do you sell gift cards?'
- seed-full-clustergold run 3: 
- seed-full-clustergold run 4: 
- seed-full-clustergold run 5: 
- seed-full-clustergold run 6: 
- seed-full-clustergold run 7: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "I can't log in after resetting my password.", 'Do you sell gift cards?'
- seed-full-clustergold run 8: 'I was charged twice for order 4471.', 'How do I update the email on my profile?', 'Tracking says delivered but there is no parcel anywhere.', 'I have two accounts, can you combine them?'
- seed-full-clustergold run 9: 'I was charged twice for order 4471.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password.", 'How do I update the email on my profile?', 'Do you sell gift cards?'
- seed-full-first run 0: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- seed-full-first run 1: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- seed-full-first run 2: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- seed-full-first run 3: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- seed-full-first run 4: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- seed-full-first run 5: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- seed-full-first run 6: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- seed-full-first run 7: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- seed-full-first run 8: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."
- seed-full-first run 9: 'I was charged twice for order 4471.', 'The mug arrived cracked, I want my money back.', "Where is my package? Tracking hasn't moved in 5 days.", "I can't log in after resetting my password."

Mean [bootstrap 95% interval over runs].
