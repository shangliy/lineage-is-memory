Held-out best per run, and per label the share of proposals that get all search examples of the label right (first number) and the held-out best candidates that get all held-out examples right (second). Tokens exclude held-out scoring; to solve: median over runs that solved the search set.

| cell | runs | tokens / run | solved | tokens to solve | best chars | held-out best | iso | us_slash | eu_dot | long_us | long_eu | compact | slash_ymd | with_time | ordinal | short_year | weekday | invalid |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| parent-full-clustergold | 10 | 10336 | 10/10 | 7230 | 500 | 0.996 [0.988, 1.000] | 15/15, 10/10 | 14/15, 10/10 | 13/15, 10/10 | 15/15, 10/10 | 15/15, 10/10 | 14/15, 9/10 | 14/15, 10/10 | 14/15, 10/10 | 15/15, 10/10 | 14/15, 10/10 | 14/15, 10/10 | 15/15, 10/10 |
| seed-full-clustergold | 10 | 6535 | 10/10 | 6364 | 334 | 1.000 [1.000, 1.000] | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 | 10/10, 10/10 |

Wrong answers shown to the seed's first rewrite:

- parent-full-clustergold run 0: 
- parent-full-clustergold run 1: 
- parent-full-clustergold run 2: 
- parent-full-clustergold run 3: '2024-03-05', '03/05/2024', '2024-03-05T14:30:00Z', '2024-02-30', 'November 30, 2019'
- parent-full-clustergold run 4: 
- parent-full-clustergold run 5: 
- parent-full-clustergold run 6: 
- parent-full-clustergold run 7: 
- parent-full-clustergold run 8: 
- parent-full-clustergold run 9: 
- seed-full-clustergold run 0: 
- seed-full-clustergold run 1: '2024-03-05', 'March 5, 2024', '03/05/2024', '2024-03-05T14:30:00Z', '2024-02-30'
- seed-full-clustergold run 2: '2024-03-05', 'November 30, 2019', '2024-03-05T14:30:00Z', '2024-02-30'
- seed-full-clustergold run 3: '2024-03-05', 'November 30, 2019', '2024-03-05T14:30:00Z', '2024-02-30'
- seed-full-clustergold run 4: 
- seed-full-clustergold run 5: '2024-03-05', '2019-11-30 23:59', 'November 30, 2019', '2024-02-30'
- seed-full-clustergold run 6: 
- seed-full-clustergold run 7: '2024-03-05', 'March 5, 2024', '2024-03-05T14:30:00Z', '2024-02-30'
- seed-full-clustergold run 8: '2024-03-05', '2024-03-05T14:30:00Z', '2024-02-30'
- seed-full-clustergold run 9: 

Mean [bootstrap 95% interval over runs].
