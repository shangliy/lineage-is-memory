Held-out best per run, and per label the share of proposals that get all search examples of the label right (first number) and the held-out best candidates that get all held-out examples right (second). Tokens exclude held-out scoring; to solve: median over runs that solved the search set.

| cell | runs | tokens / run | solved | tokens to solve | best chars | held-out best | iso_date | us_date | eu_date | time | ipv4 | ipv6 | mac_address | uuid | email | url | hex_color | semver |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| parent-full-clustergold | 10 | 15497 | 10/10 | 14202 | 618 | 0.958 [0.946, 0.971] | 26/26, 10/10 | 18/26, 10/10 | 13/26, 10/10 | 11/26, 10/10 | 24/26, 10/10 | 21/26, 10/10 | 26/26, 10/10 | 19/26, 10/10 | 25/26, 1/10 | 24/26, 10/10 | 21/26, 10/10 | 25/26, 10/10 |
| seed-full-clustergold | 10 | 33288 | 0/10 | - | 367 | 0.683 [0.600, 0.762] | 55/70, 8/10 | 33/70, 7/10 | 9/70, 2/10 | 0/70, 0/10 | 50/70, 8/10 | 42/70, 7/10 | 64/70, 10/10 | 18/70, 7/10 | 51/70, 0/10 | 57/70, 7/10 | 24/70, 6/10 | 53/70, 10/10 |

Wrong answers shown to the seed's first rewrite:

- parent-full-clustergold run 0: 
- parent-full-clustergold run 1: 
- parent-full-clustergold run 2: 
- parent-full-clustergold run 3: 
- parent-full-clustergold run 4: 
- parent-full-clustergold run 5: 
- parent-full-clustergold run 6: 
- parent-full-clustergold run 7: 
- parent-full-clustergold run 8: 
- parent-full-clustergold run 9: 
- seed-full-clustergold run 0: 
- seed-full-clustergold run 1: 
- seed-full-clustergold run 2: '192.168.1.10', 'ana@example.com', '2.0.0-rc.1'
- seed-full-clustergold run 3: '2024-03-15', '8.8.8.8', 'ana@example.com', '#1a2b3c', '1.4.2'
- seed-full-clustergold run 4: 
- seed-full-clustergold run 5: 
- seed-full-clustergold run 6: 
- seed-full-clustergold run 7: 
- seed-full-clustergold run 8: 
- seed-full-clustergold run 9: 

Mean [bootstrap 95% interval over runs].
