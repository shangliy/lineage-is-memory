## duration

Coverage: share of proposals (first number) and of run-best candidates (second) that pass every held-out case of the category.

| cell | runs | tokens / run | solved | tokens to solve (median) | held-out best | clock | days/weeks | invalid | iso | number | units | words |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| parent-full-clustergold | 10 | 11809 | 10/10 | 10321.0 | 0.971 [0.946, 0.992] | 34/37, 10/10 | 21/37, 9/10 | 14/37, 6/10 | 29/37, 10/10 | 27/37, 10/10 | 20/37, 9/10 | 24/37, 10/10 |
| seed-full-clustergold | 10 | 17468 | 0/10 | - | 0.637 [0.554, 0.733] | 66/110, 7/10 | 25/110, 3/10 | 0/110, 0/10 | 40/110, 4/10 | 23/110, 5/10 | 35/110, 6/10 | 12/110, 2/10 |

Failures shown to the seed's first rewrite:

- parent-full-clustergold: '90', '1h30m', '1h 30m 15s', '3d', '1w', '2 hours', '1 minute 30 seconds', '01:30:00', '2:05', 'PT1H30M', 'P1DT2H', '1x', '-5m'
- seed-full-clustergold: '90', '1h30m', '1h 30m 15s', '3d', '1w', '2 hours', '1 minute 30 seconds', '01:30:00', '2:05', 'PT1H30M', 'P1DT2H', '1x', '-5m'

## size

Coverage: share of proposals (first number) and of run-best candidates (second) that pass every held-out case of the category.

| cell | runs | tokens / run | solved | tokens to solve (median) | held-out best | bytes | iec | invalid | letter | separator | si | words |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| parent-full-clustergold | 10 | 12568 | 8/10 | 8251.0 | 0.963 [0.917, 1.000] | 54/55, 10/10 | 41/55, 9/10 | 55/55, 10/10 | 35/55, 10/10 | 52/55, 10/10 | 40/55, 9/10 | 28/55, 7/10 |
| seed-full-clustergold | 10 | 17267 | 1/10 | 8142 | 0.875 [0.821, 0.929] | 101/103, 10/10 | 47/103, 5/10 | 100/103, 10/10 | 19/103, 8/10 | 81/103, 8/10 | 96/103, 10/10 | 64/103, 5/10 |

Failures shown to the seed's first rewrite:

- parent-full-clustergold: '512', '10KB', '1.5MB', '3 GB', '1kB', '1KiB', '4MiB', '2Gi', '256Mi', '1.5K', '512m', '10 kilobytes', '1 byte', '2 gibibytes', '1,024'
- seed-full-clustergold: '512', '10KB', '1.5MB', '3 GB', '1kB', '1KiB', '4MiB', '2Gi', '256Mi', '1.5K', '512m', '10 kilobytes', '1 byte', '2 gibibytes', '1,024'

Mean [bootstrap 95% interval over runs].
