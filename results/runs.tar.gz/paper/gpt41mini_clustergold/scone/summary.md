Held-out best per run, and per label the share of proposals that get all search examples of the label right (first number) and the held-out best candidates that get all held-out examples right (second). Tokens exclude held-out scoring; to solve: median over runs that solved the search set.

| cell | runs | tokens / run | solved | tokens to solve | best chars | held-out best | no_negation | one_scoped | one_not_scoped | two_scoped | two_not_scoped | one_scoped_one_not_scoped |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| parent-full-clustergold | 10 | 60245 | 0/10 | - | 403 | 0.900 [0.885, 0.917] | 69/70, 10/10 | 2/70, 1/10 | 70/70, 8/10 | 52/70, 0/10 | 68/70, 10/10 | 41/70, 0/10 |
| seed-full-clustergold | 10 | 49988 | 0/10 | - | 319 | 0.908 [0.894, 0.924] | 68/70, 10/10 | 0/70, 0/10 | 68/70, 6/10 | 63/70, 0/10 | 68/70, 10/10 | 57/70, 0/10 |

Wrong answers shown to the seed's first rewrite:

- parent-full-clustergold run 0: 
- parent-full-clustergold run 1: 
- parent-full-clustergold run 2: 
- parent-full-clustergold run 3: 
- parent-full-clustergold run 4: 
- parent-full-clustergold run 5: 
- parent-full-clustergold run 6: 
- parent-full-clustergold run 7: 
- parent-full-clustergold run 8: 
- parent-full-clustergold run 9: 
- seed-full-clustergold run 0: 
- seed-full-clustergold run 1: 
- seed-full-clustergold run 2: 
- seed-full-clustergold run 3: 
- seed-full-clustergold run 4: 
- seed-full-clustergold run 5: 
- seed-full-clustergold run 6: 
- seed-full-clustergold run 7: 
- seed-full-clustergold run 8: 
- seed-full-clustergold run 9: 

Mean [bootstrap 95% interval over runs].
