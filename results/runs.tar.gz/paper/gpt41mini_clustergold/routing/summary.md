Held-out best per run, and per label the share of proposals that get all search examples of the label right (first number) and the held-out best candidates that get all held-out examples right (second). Tokens exclude held-out scoring; to solve: median over runs that solved the search set.

| cell | runs | tokens / run | solved | tokens to solve | best chars | held-out best | payments | fulfillment | logistics | trust_safety | care | privacy |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| parent-full-clustergold | 10 | 54297 | 5/10 | 40430 | 2846 | 0.842 [0.783, 0.900] | 36/62, 10/10 | 26/62, 7/10 | 39/62, 1/10 | 21/62, 8/10 | 14/62, 6/10 | 41/62, 9/10 |
| seed-full-clustergold | 10 | 34826 | 0/10 | - | 839 | 0.625 [0.575, 0.675] | 3/70, 9/10 | 5/70, 3/10 | 14/70, 5/10 | 26/70, 8/10 | 9/70, 1/10 | 11/70, 3/10 |

Wrong answers shown to the seed's first rewrite:

- parent-full-clustergold run 0: 
- parent-full-clustergold run 1: 
- parent-full-clustergold run 2: 
- parent-full-clustergold run 3: 
- parent-full-clustergold run 4: 
- parent-full-clustergold run 5: 
- parent-full-clustergold run 6: 
- parent-full-clustergold run 7: 
- parent-full-clustergold run 8: 
- parent-full-clustergold run 9: 
- seed-full-clustergold run 0: 
- seed-full-clustergold run 1: 
- seed-full-clustergold run 2: 
- seed-full-clustergold run 3: 
- seed-full-clustergold run 4: 
- seed-full-clustergold run 5: 
- seed-full-clustergold run 6: 
- seed-full-clustergold run 7: 
- seed-full-clustergold run 8: 
- seed-full-clustergold run 9: 

Mean [bootstrap 95% interval over runs].
