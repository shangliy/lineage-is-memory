Held-out best per run, and per label the share of proposals that get all search examples of the label right (first number) and the held-out best candidates that get all held-out examples right (second). Tokens exclude held-out scoring; to solve: median over runs that solved the search set.

| cell | runs | tokens / run | solved | tokens to solve | best chars | held-out best | refund | password | late_order | cancel | bug | legal | feature | delete |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| parent-full-clustergold | 10 | 22233 | 9/10 | 21590 | 1555 | 0.869 [0.669, 0.981] | 20/22, 7/10 | 19/22, 9/10 | 15/22, 7/10 | 20/22, 9/10 | 20/22, 9/10 | 19/22, 9/10 | 17/22, 8/10 | 18/22, 9/10 |
| seed-full-clustergold | 10 | 40181 | 5/10 | 29543 | 1321 | 0.794 [0.600, 0.925] | 41/41, 6/10 | 36/41, 9/10 | 23/41, 4/10 | 41/41, 9/10 | 40/41, 9/10 | 35/41, 8/10 | 20/41, 6/10 | 34/41, 8/10 |

Wrong answers shown to the seed's first rewrite:

- parent-full-clustergold run 0: 
- parent-full-clustergold run 4: 
- parent-full-clustergold run 5: 
- parent-full-clustergold run 6: 
- parent-full-clustergold run 7: 
- parent-full-clustergold run 8: 
- parent-full-clustergold run 9: 
- seed-full-clustergold run 0: 
- seed-full-clustergold run 1: 
- seed-full-clustergold run 2: 
- seed-full-clustergold run 3: 
- seed-full-clustergold run 4: 
- seed-full-clustergold run 5: 
- seed-full-clustergold run 6: 
- seed-full-clustergold run 7: 
- seed-full-clustergold run 9: 

Mean [bootstrap 95% interval over runs].

Judge gpt-4.1-mini: 1778 calls, 386868 tokens.
